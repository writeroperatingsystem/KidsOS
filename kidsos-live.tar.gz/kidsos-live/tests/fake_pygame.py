"""Minimal stand-in for pygame so main.py can be smoke-tested where pygame isn't installed.
It only checks that our code runs and uses sane arguments; it does NOT prove real rendering."""
import os, sys, types

NOW = [0]
class Rect:
    def __init__(self, *a):
        if len(a) == 1: a = tuple(a[0])
        self.x, self.y, self.w, self.h = (int(v) for v in a)
    @property
    def width(self): return self.w
    @property
    def height(self): return self.h
    @property
    def right(self): return self.x + self.w
    @property
    def bottom(self): return self.y + self.h
    @property
    def centerx(self): return self.x + self.w // 2
    @property
    def centery(self): return self.y + self.h // 2
    @property
    def center(self): return (self.centerx, self.centery)
    def __iter__(self): return iter((self.x, self.y, self.w, self.h))
    def move(self, dx, dy): return Rect(self.x + dx, self.y + dy, self.w, self.h)
    def collidepoint(self, p): return self.x <= p[0] < self.right and self.y <= p[1] < self.bottom
    def colliderect(self, o): return self.x < o.right and o.x < self.right and self.y < o.bottom and o.y < self.bottom

class Surface:
    def __init__(self, size=(0, 0), *a): self.size = (int(size[0]), int(size[1]))
    def get_size(self): return self.size
    def get_width(self): return self.size[0]
    def get_height(self): return self.size[1]
    def get_rect(self, **kw):
        r = Rect(0, 0, *self.size)
        if "center" in kw: r = Rect(kw["center"][0] - r.w // 2, kw["center"][1] - r.h // 2, r.w, r.h)
        return r
    def blit(self, *a, **k): pass
    def fill(self, *a, **k): pass
    def convert_alpha(self): return self

class Font:
    def __init__(self, path, size): self.px = size or 20
    def size(self, text): return (int(len(text) * self.px * .55), int(self.px * 1.2))
    def render(self, text, aa, col): return Surface(self.size(text))

class Channel:
    def __init__(self, end): self.end = end
    def get_busy(self): return NOW[0] < self.end
    def stop(self): self.end = 0
class Sound:
    played = []
    def __init__(self, path):
        if not os.path.exists(path): raise FileNotFoundError(path)
        self.path = path
    def get_length(self): return 0.4
    def play(self): Sound.played.append(self.path); return Channel(NOW[0] + 400)

EVENTS = []
def build():
    m = types.ModuleType("pygame")
    m.Rect, m.Surface = Rect, Surface
    m.FULLSCREEN, m.QUIT, m.MOUSEBUTTONDOWN, m.KEYDOWN = 1, 256, 1025, 768
    m.K_ESCAPE, m.K_LEFT, m.K_RIGHT, m.SRCALPHA = 27, 1073741904, 1073741903, 65536
    m.init = lambda: None; m.quit = lambda: None
    m.display = types.SimpleNamespace(set_mode=lambda size, flags=0: Surface((1280, 720) if tuple(size) == (0, 0) else size),
                                      flip=lambda: None, set_caption=lambda t: None, get_driver=lambda: 'fake')
    m.font = types.SimpleNamespace(Font=Font)
    m.mixer = types.SimpleNamespace(pre_init=lambda *a: None, init=lambda **k: None, quit=lambda: None,
                                    get_init=lambda: (22050, -16, 1), Sound=Sound)
    m.version = types.SimpleNamespace(ver="2.6.1"); m.get_sdl_version = lambda: (2, 30, 0)
    m.image = types.SimpleNamespace(load=lambda p: Surface((512, 512)) if os.path.exists(p) else (_ for _ in ()).throw(FileNotFoundError(p)))
    m.transform = types.SimpleNamespace(smoothscale=lambda s, size: Surface(size))
    noop = lambda *a, **k: None
    m.draw = types.SimpleNamespace(rect=noop, circle=noop, polygon=noop, line=noop, arc=noop, ellipse=noop)
    m.event = types.SimpleNamespace(get=lambda: [EVENTS.pop(0)] if EVENTS else [])
    class Clock:
        def tick(self, fps): NOW[0] += 33
    m.time = types.SimpleNamespace(get_ticks=lambda: NOW[0], Clock=Clock)
    return m

def install():
    sys.modules["pygame"] = build()
    return sys.modules["pygame"]
