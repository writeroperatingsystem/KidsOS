import os, random, sys, unittest
ABC = os.path.join(os.path.dirname(__file__), "..", "config/includes.chroot/usr/local/lib/kidsos/activities/abc-letters")
sys.path.insert(0, ABC)
import logic

class TestContent(unittest.TestCase):
    def test_26_unique_letters(self):
        self.assertEqual([i.letter for i in logic.ITEMS], list("abcdefghijklmnopqrstuvwxyz"))
    def test_every_picture_exists(self):
        for i in logic.ITEMS: self.assertTrue(os.path.exists(os.path.join(ABC, "images", i.letter + ".png")), i.letter)
    def test_sfx_exist(self):
        for n in ("tap", "correct", "cheer"): self.assertTrue(os.path.exists(os.path.join(ABC, "sfx", n + ".wav")))
    def test_matchable_excludes_only_x(self):
        self.assertEqual({i.letter for i in logic.ITEMS} - {i.letter for i in logic.MATCHABLE}, {"x"})
    def test_no_two_match_words_share_initial(self):
        firsts = [i.word[0] for i in logic.MATCHABLE]; self.assertEqual(len(firsts), len(set(firsts)))
    def test_voice_clips(self):
        clips = logic.voice_clips(); names = [c[0] for c in clips]
        self.assertEqual(len(clips), 26 * 2 + len(logic.PROMPTS)); self.assertEqual(len(names), len(set(names)))

class TestLearn(unittest.TestCase):
    def test_wrap_and_jump(self):
        l = logic.Learn(); l.prev(); self.assertEqual(l.item.letter, "z"); l.next(); self.assertEqual(l.item.letter, "a")
        self.assertTrue(l.jump("M")); self.assertEqual(l.item.letter, "m"); self.assertFalse(l.jump("7")); self.assertEqual(l.item.letter, "m")

class TestMatch(unittest.TestCase):
    def test_many_games(self):
        for seed in range(300):
            m = logic.Match(random.Random(seed))
            self.assertEqual(len({t.letter for t in m.targets}), logic.MATCH_ROUNDS)
            self.assertNotIn("x", [t.letter for t in m.targets])
            while not m.finished:
                self.assertEqual(len(m.choices), 3)
                self.assertEqual(len({c.letter for c in m.choices}), 3)
                self.assertIn(m.target, m.choices)
                self.assertNotIn("x", [c.letter for c in m.choices])
                self.assertEqual(sum(c.word[0] == m.target.letter for c in m.choices), 1)  # exactly one right answer
                m.advance()
            self.assertEqual(m.round, logic.MATCH_ROUNDS)
    def test_wrong_then_hint_then_right(self):
        m = logic.Match(random.Random(1)); wrong = [c for c in m.choices if c != m.target]
        self.assertFalse(m.answer(wrong[0])); self.assertFalse(m.hint)
        self.assertFalse(m.answer(wrong[1])); self.assertTrue(m.hint)
        self.assertTrue(m.answer(m.target)); m.advance(); self.assertEqual(m.misses, 0); self.assertFalse(m.hint)

if __name__ == "__main__": unittest.main()
