import os, sys, unittest
HERE = os.path.dirname(__file__); sys.path.insert(0, HERE)
import fake_pygame as fp
pg = fp.install()
ABC = os.path.join(HERE, "..", "config/includes.chroot/usr/local/lib/kidsos/activities/abc-letters")
sys.path.insert(0, ABC)
import main as abc_main
from logic import ITEMS, MATCH_ROUNDS

def step(app, ms=1500):
    for _ in range(ms // 33): app.update(); app.draw(); app.clock.tick(30)

class Smoke(unittest.TestCase):
    def test_layout_all_resolutions(self):
        for size in [(800, 600), (1024, 768), (1280, 720), (1366, 768), (1920, 1080)]:
            a = abc_main.App(size); full = pg.Rect(0, 0, *size)
            fixed = [a.home_r, a.mode_r, a.prev_r, a.next_r, a.letter_r, a.pic_r, a.tile_r] + a.choice_r + a.done_r
            for r in fixed:
                self.assertTrue(full.collidepoint((r.x, r.y)) and r.right <= size[0] and r.bottom <= size[1], (size, tuple(r)))
            self.assertFalse(a.pic_r.colliderect(a.prev_r) or a.pic_r.colliderect(a.next_r) or a.letter_r.colliderect(a.prev_r), size)
            self.assertFalse(a.letter_r.colliderect(a.pic_r), size)
            self.assertFalse(a.tile_r.colliderect(a.home_r) or a.tile_r.colliderect(a.mode_r), size)
            for i, r in enumerate(a.choice_r):
                self.assertGreaterEqual(r.y, a.dots_y, size)
                for o in a.choice_r[i + 1:]: self.assertFalse(r.colliderect(o), size)
                self.assertGreater(r.w, size[1] * .3, size)    # pictures stay LARGE

    def test_full_session(self):
        fp.Sound.played.clear()
        a = abc_main.App((1280, 720))
        step(a)                                           # first letter is spoken (a, then word)
        for _ in range(3): a.click(a.next_r.center); step(a, 300)
        self.assertEqual(a.learn.item.letter, "d")
        e = type("E", (), {"key": 0, "unicode": "z"})(); a.key(e); self.assertEqual(a.learn.item.letter, "z")
        a.click(a.letter_r.center); a.click(a.pic_r.center); step(a, 500)
        a.click(a.mode_r.center); self.assertEqual(a.mode, "match")
        for rnd in range(MATCH_ROUNDS):
            step(a, 800)
            wrong = next(i for i, c in enumerate(a.match.choices) if c != a.match.target)
            a.click(a.choice_r[wrong].center); step(a, 800)                    # wrong: only a retry
            self.assertEqual(a.match.round, rnd)
            a.click(a.tile_r.center); step(a, 300)                             # replay sound
            right = a.match.choices.index(a.match.target)
            a.click(a.choice_r[right].center); step(a, 2500)                   # correct: auto-advance
            self.assertEqual(a.match.round, rnd + 1)
        self.assertEqual(a.mode, "done"); step(a, 600)
        self.assertTrue(any(p.endswith("correct.wav") for p in fp.Sound.played)); self.assertTrue(any(p.endswith("cheer.wav") for p in fp.Sound.played))
        a.click(a.done_r[0].center); self.assertEqual(a.mode, "match"); self.assertEqual(a.match.round, 0)
        a.click(a.mode_r.center); self.assertEqual(a.mode, "learn")
        a.click(a.home_r.center); self.assertFalse(a.running)

    def test_run_loop_exits_on_escape(self):
        a = abc_main.App((1024, 768))
        fp.EVENTS.extend([type("E", (), {"type": pg.KEYDOWN, "key": pg.K_ESCAPE, "unicode": ""})()]); a.run()
        self.assertFalse(a.running)

    def test_placeholder_audio_plays_when_no_real_voice(self):
        fp.Sound.played.clear(); a = abc_main.App((1280, 720)); step(a, 1500)
        voice = [p for p in fp.Sound.played if "voice" in p]
        self.assertTrue(voice and all("voice-placeholder" in p for p in voice), voice)
        self.assertTrue(voice[0].endswith(os.path.join("letters", "a.wav")))      # letter sound first...
        self.assertTrue(any(p.endswith(os.path.join("words", "a.wav")) for p in voice))  # ...then its word

class VoiceTests(unittest.TestCase):
    def setUp(self): import tempfile; self.d = tempfile.mkdtemp(); fp.Sound.played.clear()
    def touch(self, rel):
        p = os.path.join(self.d, rel); os.makedirs(os.path.dirname(p), exist_ok=True); 
        with open(p, "wb") as f: f.write(b"x")
        return p
    def play(self, v, *names):
        v.say(*names)
        for _ in range(60): fp.NOW[0] += 100; v.update(fp.NOW[0])
    def test_empty_folder_is_silent_and_logged_once(self):
        v = abc_main.Voice(self.d); self.play(v, "voice/letters/a", "voice/letters/a")
        self.assertEqual(fp.Sound.played, []); self.assertEqual(v.missing, {"voice/letters/a"})
    def test_real_voice_beats_placeholder(self):
        real = self.touch("voice/letters/a.wav"); self.touch("voice-placeholder/letters/a.wav")
        v = abc_main.Voice(self.d); self.play(v, "voice/letters/a"); self.assertEqual(fp.Sound.played, [real])
    def test_placeholder_used_when_no_real(self):
        ph = self.touch("voice-placeholder/words/b.wav")
        v = abc_main.Voice(self.d); self.play(v, "voice/words/b"); self.assertEqual(fp.Sound.played, [ph]); self.assertIn("voice/words/b", v.placeholder_used)
    def test_ogg_accepted(self):
        o = self.touch("voice/words/c.ogg"); v = abc_main.Voice(self.d); self.play(v, "voice/words/c"); self.assertEqual(fp.Sound.played, [o])
    def test_audio_init_failure_falls_back_then_goes_silent(self):
        calls = []
        def boom(**k): calls.append(os.environ.get("SDL_AUDIODRIVER")); raise RuntimeError("no device")
        old = pg.mixer.init; pg.mixer.init = boom
        try: v = abc_main.Voice(self.d)
        finally: pg.mixer.init = old; os.environ.pop("SDL_AUDIODRIVER", None)
        self.assertFalse(v.ok); self.assertEqual(calls, [None, "alsa"])      # tried default, then ALSA
        v.say("sfx/x"); v.update(0)                                          # must not raise
    def test_corrupt_clip_is_skipped(self):
        bad = self.touch("voice/words/d.wav"); good = self.touch("voice-placeholder/words/d.wav")
        orig = fp.Sound.__init__
        def picky(self_, path):
            if path == bad: raise RuntimeError("corrupt")
            orig(self_, path)
        fp.Sound.__init__ = picky
        try: v = abc_main.Voice(self.d); self.play(v, "voice/words/d")
        finally: fp.Sound.__init__ = orig
        self.assertEqual(fp.Sound.played, [good])                           # falls through to the placeholder

class RobustnessTests(unittest.TestCase):
    def setUp(self):
        import tempfile; self.logdir = tempfile.mkdtemp(); os.environ["KIDSOS_LOG_DIR"] = self.logdir; fp.EVENTS.clear()
    def tearDown(self): os.environ.pop("KIDSOS_LOG_DIR", None)
    def log(self):
        with open(os.path.join(self.logdir, "abc.log")) as f: return f.read()
    def esc(self): return type("E", (), {"type": pg.KEYDOWN, "key": pg.K_ESCAPE, "unicode": ""})()

    def test_normal_run_logs_diagnostics(self):
        fp.EVENTS.append(self.esc()); self.assertEqual(abc_main.main(["--window"]), 0)
        t = self.log()
        for want in ("starting", "pygame 2.6.1", "audio ready", "voice clips: 0 recorded, 56 placeholder, 0 missing", "finished (exit code 0)"):
            self.assertIn(want, t)
    def test_fullscreen_failure_falls_back_to_window(self):
        orig = pg.display.set_mode
        def picky(size, flags=0):
            if tuple(size) == (0, 0): raise RuntimeError("no fullscreen")
            return orig(size, flags)
        pg.display.set_mode = picky
        try: fp.EVENTS.append(self.esc()); self.assertEqual(abc_main.main([]), 0)
        finally: pg.display.set_mode = orig
        self.assertIn("full-screen mode failed", self.log())
    def test_display_failure_returns_1_and_logs(self):
        orig = pg.display.set_mode
        def dead(*a, **k): raise RuntimeError("no display")
        pg.display.set_mode = dead
        try: self.assertEqual(abc_main.main([]), 1)
        finally: pg.display.set_mode = orig
        self.assertIn("FATAL", self.log()); self.assertIn("no display", self.log())
    def test_endless_frame_errors_exit_instead_of_hanging(self):
        orig = abc_main.App.draw
        def bad(self_): raise ValueError("boom")
        abc_main.App.draw = bad
        try: self.assertEqual(abc_main.main(["--window"]), 1)
        finally: abc_main.App.draw = orig
        self.assertIn("too many errors", self.log()); self.assertIn("ValueError: boom", self.log())
    def test_one_bad_frame_does_not_stop_the_activity(self):
        orig = abc_main.App.draw; n = [0]
        def flaky(self_):
            n[0] += 1
            if n[0] == 3: raise ValueError("once")
            orig(self_)
        abc_main.App.draw = flaky
        fp.EVENTS.extend([type("E", (), {"type": 0, "key": 0, "unicode": ""})()] * 6 + [self.esc()])
        try: self.assertEqual(abc_main.main(["--window"]), 0)
        finally: abc_main.App.draw = orig
        self.assertIn("ValueError: once", self.log())
    def test_missing_picture_does_not_crash(self):
        a = abc_main.App((1280, 720)); a.raw["a"] = None; a.imgs.clear(); step(a, 200)

if __name__ == "__main__": unittest.main()
