#!/bin/bash
# Build the KidsOS ISO. Needs a Debian (or Ubuntu) host, root, and internet.
#   sudo ./build.sh            normal image: no accounts, no shell, no root password
#   sudo ./build.sh --debug    DEVELOPER image: root password "root", reachable only by
#                              adding 'kidsos.maint' to the kernel line. Never distribute.
set -euo pipefail
cd "$(dirname "$0")"

[ "$(id -u)" -eq 0 ] || { echo "Run as root: sudo ./build.sh"; exit 1; }
command -v lb >/dev/null || { apt-get update && apt-get install -y live-build; }

MARK=config/includes.chroot/etc/kidsos/debug
OUT=kidsos-0.1-amd64.iso
trap 'rm -f "$MARK"; rmdir config/includes.chroot/etc/kidsos 2>/dev/null || true' EXIT
if [ "${1:-}" = "--debug" ]; then
    mkdir -p "$(dirname "$MARK")"; touch "$MARK"; OUT=kidsos-0.1-amd64-DEBUG.iso
    echo ">>> DEBUG build: do not distribute <<<"
fi

lb clean --purge 2>/dev/null || true
lb config
lb build

[ -f live-image-amd64.hybrid.iso ] || { echo "Build failed: ISO not found (see build.log)"; exit 1; }
mv live-image-amd64.hybrid.iso "$OUT"
sha256sum "$OUT" > "$OUT.sha256"
echo "Done: $(pwd)/$OUT"
echo "Next: tools/check-branding.sh $OUT"
