#!/usr/bin/env python3
"""KidsOS - ABC: letter-to-picture.

Learn mode : big "Aa" + big picture. Tap either to hear it. Arrows (or letter keys) change letter.
Match mode : hear a letter sound, tap the picture that starts with it. 8 rounds, no losing.
Everything is spoken; the only written words are the letters and a small picture caption.
Exit with the house button (or Esc).
"""
import glob, logging, logging.handlers, math, os, random, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
VERSION = "0.2"
log = logging.getLogger("kidsos.abc")


def setup_logging():
    """Log to ~/KidsOS-logs/abc.log (persists on the pendrive); fall back to /tmp, then stderr."""
    for h in list(log.handlers):
        log.removeHandler(h); h.close()
    log.setLevel(logging.INFO); log.propagate = False
    handler = None
    for d in (os.environ.get("KIDSOS_LOG_DIR"), os.path.join(os.path.expanduser("~"), "KidsOS-logs"), "/tmp"):
        if not d: continue
        try:
            os.makedirs(d, exist_ok=True)
            handler = logging.handlers.RotatingFileHandler(os.path.join(d, "abc.log"), maxBytes=200000,
                                                           backupCount=1, encoding="utf-8")
            break
        except OSError:
            continue
    handler = handler or logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    log.addHandler(handler)


try:
    import pygame
except ImportError:
    setup_logging()
    log.error("pygame is not installed. Fix: sudo apt install python3-pygame")
    print("ABC: pygame is not installed (sudo apt install python3-pygame)", file=sys.stderr)
    sys.exit(2)
from logic import ITEMS, BY_LETTER, MATCH_ROUNDS, Learn, Match, voice_clips

BLUE, PANEL, WHITE, INK = (27, 108, 168), (245, 250, 255), (255, 255, 255), (45, 52, 80)
YELLOW, GREEN, ORANGE, PURPLE = (241, 196, 15), (39, 174, 96), (230, 126, 34), (142, 68, 173)
R = pygame.Rect


# ---------------------------------------------------------------- voice / sound
class Voice:
    """Plays a queue of clips one after another without blocking the UI.
    Names: 'voice/letters/a' (looked up in voice/, then voice-placeholder/) or 'sfx/correct'.
    .wav or .ogg. Missing/broken clips are logged once and skipped; the app never crashes over audio."""
    def __init__(self, base):
        self.base, self.cache, self.queue, self.channel, self.ready_at = base, {}, [], None, 0
        self.placeholder_used, self.missing = set(), set()
        self.ok = self._init_mixer()

    @staticmethod
    def _init_mixer():
        for driver in (None, "alsa"):          # second try: bypass the sound server, talk to ALSA directly
            try:
                if driver:
                    os.environ["SDL_AUDIODRIVER"] = driver; pygame.mixer.quit()
                pygame.mixer.init(frequency=22050, size=-16, channels=1, buffer=512)
                log.info("audio ready (%s): %s", driver or "default driver", pygame.mixer.get_init())
                return True
            except Exception as e:
                log.warning("audio init failed (%s): %s", driver or "default driver", e)
        log.error("NO AUDIO: continuing silently")
        return False

    def _candidates(self, name):
        if name.startswith("voice/"):
            rel = name[len("voice/"):]
            return [("voice", os.path.join(self.base, "voice", rel)),
                    ("placeholder", os.path.join(self.base, "voice-placeholder", rel))]
        return [("sfx", os.path.join(self.base, name))]

    def _load(self, name):
        if name in self.cache: return self.cache[name]
        snd = None
        for kind, stem in self._candidates(name):
            for ext in (".wav", ".ogg"):
                path = stem + ext
                if not os.path.exists(path): continue
                try:
                    snd = pygame.mixer.Sound(path)
                    if kind == "placeholder": self.placeholder_used.add(name)
                except Exception as e:
                    log.warning("cannot load %s: %s", path, e)
                if snd: break
            if snd: break
        if snd is None and name not in self.missing:
            self.missing.add(name); log.info("no audio for %s", name)
        self.cache[name] = snd
        return snd

    def say(self, *names, gap=250):
        """Replace whatever is playing with this sequence."""
        self.stop()
        self.ready_at = 0
        self.queue = [(n, gap) for n in names]

    def stop(self):
        self.queue = []
        if self.ok and self.channel is not None:
            try: self.channel.stop()
            except Exception: pass

    def busy(self):
        return bool(self.queue) or (self.ok and self.channel is not None and self.channel.get_busy())

    def update(self, now):
        if not self.ok: self.queue = []; return
        if self.channel is not None and self.channel.get_busy(): return
        while self.queue and now >= self.ready_at:
            name, gap = self.queue.pop(0)
            snd = self._load(name)
            if snd is None: continue
            try: self.channel = snd.play()
            except Exception as e: log.warning("cannot play %s: %s", name, e); continue
            self.ready_at = now + int(snd.get_length() * 1000) + gap
            return


# ---------------------------------------------------------------- drawing helpers
def _font_path():
    for pat in ("/usr/share/fonts/**/ComicNeue-Bold.*", "/usr/share/fonts/**/DejaVuSans-Bold.ttf"):
        hits = glob.glob(pat, recursive=True)
        if hits: return hits[0]
    return None
FONT_PATH = _font_path()

def shade(c, d): return tuple(max(0, min(255, v + d)) for v in c)

def star_points(cx, cy, r):
    return [(cx + (r if i % 2 == 0 else r * .45) * math.sin(i * math.pi / 5),
             cy - (r if i % 2 == 0 else r * .45) * math.cos(i * math.pi / 5)) for i in range(10)]

def icon_home(s, r, c):
    x, y, w, h = r
    pygame.draw.polygon(s, c, [(x + w * .5, y + h * .2), (x + w * .16, y + h * .52), (x + w * .84, y + h * .52)])
    pygame.draw.rect(s, c, (x + w * .27, y + h * .5, w * .46, h * .32))
    pygame.draw.rect(s, shade(c, -90), (x + w * .44, y + h * .6, w * .12, h * .22))

def icon_star(s, r, c): pygame.draw.polygon(s, c, star_points(r.centerx, r.centery + r.h * .03, r.h * .34))

def icon_book(s, r, c):
    x, y, w, h = r
    pygame.draw.rect(s, c, (x + w * .2, y + h * .28, w * .27, h * .44), border_radius=int(h * .04))
    pygame.draw.rect(s, c, (x + w * .53, y + h * .28, w * .27, h * .44), border_radius=int(h * .04))

def icon_arrow(s, r, c, direction):
    x, y, w, h = r; d = direction
    pygame.draw.polygon(s, c, [(x + w * (.5 + .2 * d), y + h * .5), (x + w * (.5 - .16 * d), y + h * .24), (x + w * (.5 - .16 * d), y + h * .76)])

def icon_replay(s, r, c):
    cx, cy, rad = r.centerx, r.centery, r.h * .26
    pygame.draw.arc(s, c, (cx - rad, cy - rad, rad * 2, rad * 2), 0.6, 5.6, max(4, int(r.h * .09)))
    ax, ay = cx + rad * math.cos(0.6), cy - rad * math.sin(0.6)
    pygame.draw.polygon(s, c, [(ax - r.h * .02, ay - r.h * .2), (ax + r.h * .16, ay + r.h * .03), (ax - r.h * .13, ay + r.h * .08)])

def icon_speaker(s, r, c):
    x, y, w, h = r
    pygame.draw.polygon(s, c, [(x + w * .22, y + h * .4), (x + w * .38, y + h * .4), (x + w * .56, y + h * .24),
                               (x + w * .56, y + h * .76), (x + w * .38, y + h * .6), (x + w * .22, y + h * .6)])
    for k in (1, 2):
        pygame.draw.arc(s, c, (x + w * (.5 - .04 * k), y + h * (.5 - .14 * k), w * .26 * k * .9, h * .28 * k), -.9, .9, max(3, int(h * .05)))

def button(s, r, color, icon):
    pygame.draw.rect(s, shade(color, -55), r.move(0, max(3, int(r.h * .06))), border_radius=r.h // 4)
    pygame.draw.rect(s, color, r, border_radius=r.h // 4)
    icon(s, r, WHITE)


# ---------------------------------------------------------------- the app
class App:
    def __init__(self, size=None):
        try: pygame.mixer.pre_init(22050, -16, 1, 512)
        except Exception: pass
        pygame.init()
        try:
            self.screen = pygame.display.set_mode(size or (0, 0), 0 if size else pygame.FULLSCREEN)
        except Exception as e:
            log.warning("full-screen mode failed (%s); using a 1024x768 window", e)
            self.screen = pygame.display.set_mode((1024, 768))
        pygame.display.set_caption("ABC")
        self.W, self.H = self.screen.get_size()
        self.voice = Voice(HERE)
        self.exit_code = 0
        self.diagnostics()
        self.clock = pygame.time.Clock()
        self.fonts, self.imgs, self.raw = {}, {}, {}
        self.rects()
        self.mode = "learn"; self.learn = Learn(); self.match = None
        self.running = True
        self.bounce = {}            # key -> start ms
        self.shake = {}             # choice index -> start ms
        self.pending_advance = None # ms when a correct answer should move on
        self.confetti = []
        self.speak_letter()

    def diagnostics(self):
        """One-time hardware/asset summary at the top of the log (read it after a test run)."""
        def tryit(f, default="?"):
            try: return f()
            except Exception: return default
        log.info("ABC %s | python %s | pygame %s | SDL video driver %s | screen %dx%d",
                 VERSION, sys.version.split()[0], tryit(lambda: pygame.version.ver),
                 tryit(lambda: pygame.display.get_driver()), self.W, self.H)
        log.info("font: %s", FONT_PATH or "pygame default (no Comic Neue / DejaVu found)")
        real = placeholder = missing = 0
        for rel, _, _ in voice_clips():
            def has(d): return any(os.path.exists(os.path.join(HERE, d, rel + e)) for e in (".wav", ".ogg"))
            if has("voice"): real += 1
            elif has("voice-placeholder"): placeholder += 1
            else: missing += 1
        log.info("voice clips: %d recorded, %d placeholder, %d missing", real, placeholder, missing)

    # ---- layout
    def rects(self):
        W, H = self.W, self.H
        m = self.m = max(8, int(H * .03)); bar = self.bar = int(H * .14)
        self.home_r = R(m, m, bar, bar); self.mode_r = R(W - m - bar, m, bar, bar)
        nav = self.nav = int(H * .16)
        self.prev_r = R(W // 2 - nav - m, H - m - nav, nav, nav); self.next_r = R(W // 2 + m, H - m - nav, nav, nav)
        top, bottom = bar + 2 * m, H - 2 * m - nav
        lw = int((W - 3 * m) * .42)
        self.letter_r = R(m, top, lw, bottom - top)
        self.pic_r = R(2 * m + lw, top, W - 3 * m - lw, bottom - top)
        # match mode
        th = int(H * .30); tw = int(th * 1.25)
        self.tile_r = R(W // 2 - tw // 2, m, tw, th)
        self.dots_y = m + th + int(H * .035)
        cy = self.dots_y + int(H * .045); ch = H - cy - m
        cw = (W - 4 * m) // 3; side = min(ch, cw)
        self.choice_r = [R(m + i * (cw + m) + (cw - side) // 2, cy + (ch - side) // 2, side, side) for i in range(3)]
        # done screen
        b = int(H * .2); self.done_r = [R(W // 2 + (i - 1) * (b + m) - b // 2, int(H * .62), b, b) for i in range(3)]

    # ---- assets
    def font(self, size):
        size = max(8, int(size))
        if size not in self.fonts:
            self.fonts[size] = pygame.font.Font(FONT_PATH, size) if FONT_PATH else pygame.font.Font(None, size)
        return self.fonts[size]

    def image(self, letter, side):
        key = (letter, side)
        if key not in self.imgs:
            if letter not in self.raw:
                try: self.raw[letter] = pygame.image.load(os.path.join(HERE, "images", letter + ".png")).convert_alpha()
                except Exception: self.raw[letter] = None
            raw = self.raw[letter]
            self.imgs[key] = pygame.transform.smoothscale(raw, (side, side)) if raw else None
        return self.imgs[key]

    # ---- speaking
    def speak_letter(self, with_word=True):
        l = self.learn.item.letter
        self.voice.say(f"voice/letters/{l}", *([f"voice/words/{l}"] if with_word else []))

    def start_match(self):
        self.mode = "match"; self.match = Match(); self.pending_advance = None; self.shake = {}
        self.voice.say("voice/prompts/which", f"voice/letters/{self.match.target.letter}")

    # ---- events
    def click(self, pos):
        now = pygame.time.get_ticks()
        if self.home_r.collidepoint(pos): self.running = False; return
        if self.mode == "learn":
            if self.mode_r.collidepoint(pos): self.start_match()
            elif self.prev_r.collidepoint(pos): self.learn.prev(); self.speak_letter()
            elif self.next_r.collidepoint(pos): self.learn.next(); self.speak_letter()
            elif self.letter_r.collidepoint(pos):
                self.bounce["letter"] = now; self.speak_letter(with_word=False)
            elif self.pic_r.collidepoint(pos):
                self.bounce["pic"] = now; self.voice.say(f"voice/words/{self.learn.item.letter}")
        elif self.mode == "match":
            if self.mode_r.collidepoint(pos): self.mode = "learn"; self.speak_letter()
            elif self.tile_r.collidepoint(pos): self.voice.say(f"voice/letters/{self.match.target.letter}")
            elif self.pending_advance is None:
                for i, r in enumerate(self.choice_r):
                    if r.collidepoint(pos): self.pick(i); break
        elif self.mode == "done":
            for i, r in enumerate(self.done_r):
                if r.collidepoint(pos):
                    if i == 0: self.start_match()
                    elif i == 1: self.mode = "learn"; self.speak_letter()
                    else: self.running = False

    def pick(self, i):
        now = pygame.time.get_ticks(); item = self.match.choices[i]
        if self.match.answer(item):
            self.bounce[("c", i)] = now
            self.voice.say("sfx/correct", f"voice/words/{item.letter}", "voice/prompts/yes", gap=150)
            self.pending_advance = True
        else:
            self.shake[i] = now
            self.voice.say(f"voice/words/{item.letter}", "voice/prompts/try_again")

    def key(self, e):
        if e.key == pygame.K_ESCAPE: self.running = False
        elif self.mode == "learn":
            if e.key == pygame.K_RIGHT: self.learn.next(); self.speak_letter()
            elif e.key == pygame.K_LEFT: self.learn.prev(); self.speak_letter()
            elif e.unicode and self.learn.jump(e.unicode): self.speak_letter()

    # ---- per-frame
    def update(self):
        now = pygame.time.get_ticks()
        self.voice.update(now)
        if self.mode == "match" and self.pending_advance and not self.voice.busy():
            self.pending_advance = None
            self.match.advance()
            if self.match.finished:
                self.mode = "done"; self.confetti = self.make_confetti()
                self.voice.say("sfx/cheer", "voice/prompts/done")
            else:
                self.voice.say(f"voice/letters/{self.match.target.letter}")
        if self.mode == "done":
            for c in self.confetti:
                c[1] += c[3]; c[0] += c[2]
                if c[1] > self.H: c[1] = -20; c[0] = random.randint(0, self.W)

    def make_confetti(self):
        cols = [(231, 76, 60), YELLOW, GREEN, (52, 152, 219), PURPLE, ORANGE]
        return [[random.randint(0, self.W), random.randint(-self.H, 0), random.uniform(-1.5, 1.5),
                 random.uniform(2, 6), random.choice(cols)] for _ in range(70)]

    def offset(self, key, now, amp, shake=False):
        t0 = (self.shake if shake else self.bounce).get(key)
        if t0 is None: return 0
        dt = now - t0
        if dt > 600: return 0
        fall = 1 - dt / 600
        return int(math.sin(dt / 40) * amp * fall) if shake else -int(abs(math.sin(dt / 90)) * amp * fall)

    # ---- drawing
    def draw_letter_tile(self, r, item, dy=0):
        rr = r.move(0, dy)
        pygame.draw.rect(self.screen, shade(item.color, -55), rr.move(0, max(4, r.h // 28)), border_radius=r.h // 8)
        pygame.draw.rect(self.screen, item.color, rr, border_radius=r.h // 8)
        text = item.letter.upper() + item.letter
        size = r.h * .62
        while self.font(size).size(text)[0] > r.w * .86 and size > 20: size *= .93
        f = self.font(size)
        for off, col in ((max(2, int(size * .03)), shade(item.color, -70)), (0, WHITE)):
            surf = f.render(text, True, col)
            self.screen.blit(surf, surf.get_rect(center=(rr.centerx + off, rr.centery + off - int(size * .04))))

    def draw_picture(self, r, letter, dx=0, dy=0, panel=PANEL):
        rr = r.move(dx, dy)
        pygame.draw.rect(self.screen, panel, rr, border_radius=r.h // 10)
        side = int(min(r.w, r.h) * .86)
        img = self.image(letter, side)
        if img: self.screen.blit(img, img.get_rect(center=rr.center))
        return rr

    def draw_caption(self, item, r):
        f = self.font(self.H * .06)
        a, b = f.render(item.word[0], True, item.color), f.render(item.word[1:], True, INK)
        x = r.centerx - (a.get_width() + b.get_width()) // 2; y = r.bottom - self.H * .085
        self.screen.blit(a, (x, y)); self.screen.blit(b, (x + a.get_width(), y))

    def draw(self):
        now = pygame.time.get_ticks(); s = self.screen
        s.fill(BLUE)
        button(s, self.home_r, YELLOW, icon_home)
        if self.mode == "learn":
            button(s, self.mode_r, GREEN, icon_star)
            it = self.learn.item
            self.draw_letter_tile(self.letter_r, it, self.offset("letter", now, self.H * .02))
            self.draw_picture(self.pic_r, it.letter, dy=self.offset("pic", now, self.H * .02))
            self.draw_caption(it, self.pic_r)
            button(s, self.prev_r, ORANGE, lambda s_, r, c: icon_arrow(s_, r, c, -1))
            button(s, self.next_r, ORANGE, lambda s_, r, c: icon_arrow(s_, r, c, 1))
        elif self.mode == "match":
            button(s, self.mode_r, PURPLE, icon_book)
            t = self.match.target
            self.draw_letter_tile(self.tile_r, t)
            icon_speaker(s, R(self.tile_r.right - self.tile_r.h * .3, self.tile_r.bottom - self.tile_r.h * .3, self.tile_r.h * .28, self.tile_r.h * .28), WHITE)
            for k in range(MATCH_ROUNDS):
                x = self.W // 2 + (k - (MATCH_ROUNDS - 1) / 2) * self.H * .05
                if k < self.match.round: pygame.draw.polygon(s, YELLOW, star_points(x, self.dots_y, self.H * .022))
                else: pygame.draw.circle(s, WHITE, (int(x), int(self.dots_y)), int(self.H * .012))
            for i, (r, item) in enumerate(zip(self.choice_r, self.match.choices)):
                dx = self.offset(i, now, self.H * .02, shake=True); dy = self.offset(("c", i), now, self.H * .03)
                pulse = self.match.hint and item.letter == t.letter and (now // 350) % 2 == 0
                self.draw_picture(r, item.letter, dx, dy, panel=(255, 240, 150) if pulse else PANEL)
        else:  # done
            for k in range(MATCH_ROUNDS):
                x = self.W // 2 + (k - (MATCH_ROUNDS - 1) / 2) * self.H * .1
                y = self.H * .3 + math.sin(now / 250 + k) * self.H * .015
                pygame.draw.polygon(s, YELLOW, star_points(x, y, self.H * .05))
                pygame.draw.polygon(s, ORANGE, star_points(x, y, self.H * .05), 4)
            for c in self.confetti: pygame.draw.rect(s, c[4], (int(c[0]), int(c[1]), 10, 14))
            button(s, self.done_r[0], GREEN, icon_replay); button(s, self.done_r[1], PURPLE, icon_book); button(s, self.done_r[2], YELLOW, icon_home)
        pygame.display.flip()

    def run(self):
        """Main loop. A bad frame is logged and skipped; 20 bad frames in a row ends the activity
        (exit code 1) so the launcher gets control back instead of freezing on a broken screen."""
        bad = 0
        while self.running:
            try:
                for e in pygame.event.get():
                    if e.type == pygame.QUIT: self.running = False
                    elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1: self.click(e.pos)
                    elif e.type == pygame.KEYDOWN: self.key(e)
                self.update(); self.draw(); bad = 0
            except Exception:
                bad += 1
                log.exception("error in frame (%d in a row)", bad)
                if bad >= 20:
                    log.error("too many errors in a row; leaving the activity")
                    self.exit_code = 1; self.running = False
            self.clock.tick(30)
        pygame.quit()
        return self.exit_code


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    setup_logging()
    log.info("---- starting (args: %s) ----", argv or "none")
    try:
        code = App((1024, 768) if "--window" in argv else None).run()   # --window: developer testing
    except Exception:
        log.exception("FATAL: the activity could not run")
        try: pygame.quit()
        except Exception: pass
        return 1
    log.info("finished (exit code %s)", code)
    return code


if __name__ == "__main__":
    sys.exit(main())
