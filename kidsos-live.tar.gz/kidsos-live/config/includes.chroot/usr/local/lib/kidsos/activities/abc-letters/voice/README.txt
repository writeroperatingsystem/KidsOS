Voice clips go here as 22.05 kHz mono WAV (or .ogg): letters/<a-z>.wav, words/<a-z>.wav,
prompts/{which,yes,try_again,done}.wav. Missing clips are skipped silently (the app stays quiet).
Record them with:  tools/record-voice.py      (see its --help)
