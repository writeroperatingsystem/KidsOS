"""ABC activity: content and game rules. Pure Python, no pygame (so it can be unit-tested)."""
import random
from dataclasses import dataclass

@dataclass(frozen=True)
class Item:
    letter: str      # lower-case; also the file key: images/<l>.png, voice/letters/<l>, voice/words/<l>
    word: str        # shown (small) and spoken
    sound: str       # how to say the letter SOUND, for recording guidance
    color: tuple     # letter panel colour

# No blue: the activity background is blue and a blue tile would vanish into it.
_PALETTE = [(214, 69, 65), (230, 126, 34), (39, 174, 96), (142, 68, 173), (22, 160, 133), (211, 84, 140)]
_RAW = [
    ("a", "apple", "ah (short, as in apple)"), ("b", "ball", "buh (crisp, no long uh)"),
    ("c", "cat", "kuh (hard c)"),             ("d", "dog", "duh"),
    ("e", "egg", "eh (short)"),               ("f", "fish", "fff (hold it, no voice)"),
    ("g", "grapes", "guh (hard g)"),          ("h", "hat", "hh (breath, no voice)"),
    ("i", "igloo", "ih (short)"),             ("j", "jellyfish", "juh"),
    ("k", "kite", "kuh"),                     ("l", "lion", "lll (tongue behind teeth)"),
    ("m", "moon", "mmm (lips closed)"),       ("n", "nest", "nnn"),
    ("o", "orange", "o as in orange (short)"),("p", "pig", "puh (crisp)"),
    ("q", "quilt", "kwuh"),                   ("r", "rainbow", "rrr"),
    ("s", "sun", "sss (hold it)"),            ("t", "tree", "tuh (crisp)"),
    ("u", "umbrella", "uh (short)"),          ("v", "van", "vvv"),
    ("w", "whale", "wuh"),                    ("x", "box", "ks (as at the END of box)"),
    ("y", "yo-yo", "yuh"),                    ("z", "zebra", "zzz (buzz)"),
]
ITEMS = [Item(l, w, s, _PALETTE[i % len(_PALETTE)]) for i, (l, w, s) in enumerate(_RAW)]
BY_LETTER = {i.letter: i for i in ITEMS}

# Items whose picture NAME starts with their letter. "box" (x) does not, so it is only used in
# Learn mode and never in the matching game (it would clash with "ball" as a b-word).
MATCHABLE = [i for i in ITEMS if i.word[0] == i.letter]

MATCH_ROUNDS = 8
CHOICES = 3

# Voice clips the app looks for (relative to voice/, .wav or .ogg). Missing clips are skipped silently.
PROMPTS = {
    "which":     "Which picture starts with this sound?",
    "yes":       "Yes! Well done!",
    "try_again": "Try again!",
    "done":      "You did it! Great job!",
}

def voice_clips():
    """[(relative path without extension, text to say, guidance)] in recording order."""
    out = []
    for it in ITEMS:
        out.append((f"letters/{it.letter}", it.letter.upper(), f"the SOUND: {it.sound}  (NOT the letter name)"))
    for it in ITEMS:
        out.append((f"words/{it.letter}", it.word, "say the word clearly, friendly voice"))
    for k, t in PROMPTS.items():
        out.append((f"prompts/{k}", t, "warm, upbeat, slow"))
    return out


class Learn:
    """Browse the alphabet; wraps around."""
    def __init__(self, index=0):
        self.index = index % len(ITEMS)
    @property
    def item(self): return ITEMS[self.index]
    def next(self): self.index = (self.index + 1) % len(ITEMS); return self.item
    def prev(self): self.index = (self.index - 1) % len(ITEMS); return self.item
    def jump(self, letter):
        letter = letter.lower()
        if letter in BY_LETTER:
            self.index = ITEMS.index(BY_LETTER[letter]); return True
        return False


class Match:
    """8 rounds: hear a letter sound, tap the picture that starts with it.
    There is no losing: wrong answers just give another try (and a hint after two)."""
    def __init__(self, rng=None):
        self.rng = rng or random.Random()
        self.targets = self.rng.sample(MATCHABLE, MATCH_ROUNDS)
        self.round = 0
        self.misses = 0
        self._make_choices()

    def _make_choices(self):
        others = [i for i in MATCHABLE if i.letter != self.target.letter]
        ch = [self.target] + self.rng.sample(others, CHOICES - 1)
        self.rng.shuffle(ch)
        self.choices = ch
        self.misses = 0

    @property
    def finished(self): return self.round >= MATCH_ROUNDS
    @property
    def target(self): return self.targets[min(self.round, MATCH_ROUNDS - 1)]
    @property
    def hint(self): return self.misses >= 2          # show the right answer after two wrong taps

    def answer(self, item):
        """True if correct. Wrong answers only count misses."""
        if item.letter == self.target.letter:
            return True
        self.misses += 1
        return False

    def advance(self):
        self.round += 1
        if not self.finished:
            self._make_choices()
