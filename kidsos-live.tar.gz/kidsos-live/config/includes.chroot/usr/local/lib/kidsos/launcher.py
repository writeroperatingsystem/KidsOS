#!/usr/bin/env python3
"""KidsOS launcher - prototype.

Six big buttons, no text needed. No accounts, no PIN, no timers.
Power off: press and HOLD the small grey button (bottom-right) for 5 seconds.
(A deliberate hold is the only "gate": easy for an adult, boring for a toddler.)
"""
import os, subprocess, time, pygame

COMMANDS = {
    "abc":     ["/usr/local/bin/kidsos-abc"],
    "numbers": ["gcompris-qt", "--fullscreen"],
    "shapes":  ["gcompris-qt", "--fullscreen"],
    "paint":   ["tuxpaint", "--fullscreen", "--noprint",
                "--savedir=" + os.path.expanduser("~/Pictures/KidsOS")],
    "puzzles": ["gcompris-qt", "--fullscreen"],
    "stories": None,   # custom story reader not written yet
}
COLORS = {"abc": (231, 76, 60), "numbers": (52, 152, 219), "shapes": (241, 196, 15),
          "paint": (46, 204, 113), "puzzles": (155, 89, 182), "stories": (230, 126, 34)}
ORDER = ["abc", "numbers", "shapes", "paint", "puzzles", "stories"]
HOLD_SECONDS = 5

def draw_icon(s, name, r):
    w = (255, 255, 255); cx, cy = r.center; u = r.height // 5
    if name == "abc":
        f = pygame.font.SysFont("dejavusans", r.height // 2, bold=True)
        t = f.render("A", True, w); s.blit(t, t.get_rect(center=r.center))
    elif name == "numbers":
        for i in range(3): pygame.draw.circle(s, w, (cx + (i - 1) * u * 1.4, cy), u // 2)
    elif name == "shapes":
        pygame.draw.circle(s, w, (cx - u * 1.5, cy), u)
        pygame.draw.rect(s, w, (cx - u // 2, cy - u, 2 * u, 2 * u))
        pygame.draw.polygon(s, w, [(cx + u * 2, cy + u), (cx + u * 3.4, cy - u), (cx + u * 4.8, cy + u)])
    elif name == "paint":
        pygame.draw.line(s, w, (cx - u * 2, cy + u * 1.5), (cx + u * 2, cy - u * 1.5), u // 2)
        pygame.draw.circle(s, w, (cx + u * 2, cy - u * 1.5), u // 2 + 4)
    elif name == "puzzles":
        pygame.draw.rect(s, w, (cx - u * 1.5, cy - u, u * 3, u * 2))
        pygame.draw.circle(s, w, (cx + u * 1.5, cy), u // 2)
    elif name == "stories":
        pygame.draw.rect(s, w, (cx - u * 2, cy - u * 1.5, u * 2, u * 3))
        pygame.draw.rect(s, w, (cx, cy - u * 1.5, u * 2, u * 3))

def log(msg):
    """Append to ~/KidsOS-logs/launcher.log (survives on the pendrive). Never raises."""
    try:
        d = os.path.expanduser("~/KidsOS-logs"); os.makedirs(d, exist_ok=True)
        p = os.path.join(d, "launcher.log")
        if os.path.exists(p) and os.path.getsize(p) > 100000: os.replace(p, p + ".1")
        with open(p, "a") as f: f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
    except OSError:
        pass

def run(cmd):
    t0 = time.time()
    try:
        rc = subprocess.run(cmd, check=False).returncode
    except FileNotFoundError:
        log(f"cannot start {cmd[0]}: not found"); return
    except Exception as e:
        log(f"cannot start {cmd[0]}: {e}"); return
    if rc != 0:
        log(f"{os.path.basename(cmd[0])} exited with code {rc} after {time.time() - t0:.1f}s")

def main():
    pygame.init()
    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    W, H = screen.get_size()
    margin = W // 40
    bw, bh = (W - 4 * margin) // 3, (H - 3 * margin) // 2
    rects = {n: pygame.Rect(margin + (i % 3) * (bw + margin),
                            margin + (i // 3) * (bh + margin), bw, bh)
             for i, n in enumerate(ORDER)}
    power = pygame.Rect(W - 90, H - 90, 70, 70)
    hold_start = None
    clock = pygame.time.Clock()

    while True:
        for e in pygame.event.get():
            if e.type == pygame.MOUSEBUTTONDOWN:
                if power.collidepoint(e.pos):
                    hold_start = time.time()
                else:
                    for n, r in rects.items():
                        if r.collidepoint(e.pos) and COMMANDS[n]:
                            run(COMMANDS[n])
                            pygame.event.clear()
            elif e.type == pygame.MOUSEBUTTONUP:
                hold_start = None
        if hold_start and time.time() - hold_start >= HOLD_SECONDS:
            subprocess.run(["systemctl", "poweroff"])
            hold_start = None

        screen.fill((27, 108, 168))
        for n, r in rects.items():
            pygame.draw.rect(screen, COLORS[n], r, border_radius=32)
            draw_icon(screen, n, r)
        pygame.draw.rect(screen, (90, 90, 90), power, border_radius=14)
        if hold_start:
            frac = min(1.0, (time.time() - hold_start) / HOLD_SECONDS)
            pygame.draw.rect(screen, (255, 255, 255),
                             (power.x, power.bottom - int(70 * frac), 70, int(70 * frac)), border_radius=14)
        pygame.display.flip()
        clock.tick(30)

if __name__ == "__main__":
    main()
