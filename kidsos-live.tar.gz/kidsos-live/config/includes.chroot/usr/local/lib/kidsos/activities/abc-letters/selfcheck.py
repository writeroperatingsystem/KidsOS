#!/usr/bin/env python3
"""Pre-flight check for the ABC activity. Standard library only; safe to run anywhere.
    kidsos-abc --check            (or: python3 selfcheck.py)
    kidsos-abc --check --sound    also plays a test chime
Every line is OK / WARN / FAIL with a suggested fix. Exit code 1 if anything FAILED."""
import glob, os, shutil, struct, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
count = {"OK": 0, "WARN": 0, "FAIL": 0}

def say(level, msg, fix=""):
    count[level] += 1
    print(f"[{level:>4}] {msg}" + (f"\n         -> {fix}" if fix else ""))

def png_size(path):
    with open(path, "rb") as f:
        head = f.read(24)
    if head[:8] != b"\x89PNG\r\n\x1a\n": return None
    return struct.unpack(">II", head[16:24])

def main():
    # python
    v = sys.version_info
    say("OK" if v >= (3, 8) else "FAIL", f"python {v.major}.{v.minor}.{v.micro}", "" if v >= (3, 8) else "need python 3.8+")

    # pygame
    try:
        import pygame
        say("OK", f"pygame {pygame.version.ver} (SDL {'.'.join(map(str, pygame.get_sdl_version()))})")
        try:
            import pygame.mixer  # noqa: F401
        except ImportError:
            say("FAIL", "pygame has no audio module", "sudo apt install python3-pygame libsdl2-mixer-2.0-0")
    except ImportError:
        say("FAIL", "pygame is not installed", "sudo apt install python3-pygame")

    # content
    try:
        from logic import ITEMS, voice_clips
        say("OK", f"{len(ITEMS)} letters defined")
    except Exception as e:
        say("FAIL", f"cannot load logic.py: {e}"); return finish()
    bad = []
    for it in ITEMS:
        p = os.path.join(HERE, "images", it.letter + ".png")
        if not os.path.exists(p) or png_size(p) != (512, 512): bad.append(it.letter)
    say("FAIL" if bad else "OK", f"pictures: {len(ITEMS) - len(bad)}/{len(ITEMS)} good" + (f"  (bad/missing: {' '.join(bad)})" if bad else ""),
        "re-copy the whole abc-letters folder" if bad else "")
    sfx = [n for n in ("tap", "correct", "cheer") if os.path.exists(os.path.join(HERE, "sfx", n + ".wav"))]
    say("OK" if len(sfx) == 3 else "WARN", f"sound effects: {len(sfx)}/3")

    # voice
    real = place = miss = 0
    for rel, _, _ in voice_clips():
        has = lambda d: any(os.path.exists(os.path.join(HERE, d, rel + e)) for e in (".wav", ".ogg"))
        if has("voice"): real += 1
        elif has("voice-placeholder"): place += 1
        else: miss += 1
    total = real + place + miss
    if real == total: say("OK", f"voice: all {total} clips recorded")
    elif real + place == total: say("WARN", f"voice: {real} recorded, {place} PLACEHOLDER tones (beeps, not speech)", "run tools/record-voice.py to record the real ones")
    else: say("WARN", f"voice: {real} recorded, {place} placeholder, {miss} MISSING (silent)", "tools/make-placeholder-audio.py, then tools/record-voice.py")

    # font
    f = next(iter(glob.glob("/usr/share/fonts/**/ComicNeue-Bold.*", recursive=True)), None)
    d = next(iter(glob.glob("/usr/share/fonts/**/DejaVuSans-Bold.ttf", recursive=True)), None)
    if f: say("OK", f"font: Comic Neue ({f})")
    elif d: say("WARN", "font: Comic Neue not found, using DejaVu Sans Bold (letter 'a' will look two-storey)", "sudo apt install fonts-comic-neue")
    else: say("WARN", "font: none found, using pygame's default font", "sudo apt install fonts-comic-neue fonts-dejavu-core")

    # display
    if os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"): say("OK", "graphical session detected")
    else: say("WARN", "no DISPLAY: start this from a desktop or the KidsOS launcher, not a bare text console")

    # audio hardware
    cards = open("/proc/asound/cards").read().strip() if os.path.exists("/proc/asound/cards") else ""
    if cards and "no soundcards" not in cards: say("OK", "sound card: " + cards.splitlines()[0].strip())
    else: say("WARN", "no sound card found", "check the laptop's audio (BIOS) and `aplay -l`; ABC will run silently")
    if shutil.which("amixer"):
        out = subprocess.run(["amixer", "sget", "Master"], capture_output=True, text=True).stdout
        if "[off]" in out: say("WARN", "ALSA 'Master' is MUTED", "amixer sset Master unmute   (KidsOS does this automatically at start)")

    # memory + logs
    try:
        kb = int(next(l for l in open("/proc/meminfo") if l.startswith("MemTotal")).split()[1])
        say("OK" if kb > 900_000 else "WARN", f"memory: {kb // 1024} MB", "" if kb > 900_000 else "under 1 GB: expect it to be tight")
    except Exception: pass
    logdir = os.environ.get("KIDSOS_LOG_DIR") or os.path.join(os.path.expanduser("~"), "KidsOS-logs")
    try:
        os.makedirs(logdir, exist_ok=True); t = os.path.join(logdir, ".w"); open(t, "w").close(); os.remove(t)
        say("OK", f"log folder writable: {logdir}")
    except OSError as e:
        say("WARN", f"cannot write logs to {logdir} ({e}); will use /tmp")

    if "--sound" in sys.argv:
        wav = os.path.join(HERE, "sfx", "correct.wav")
        if shutil.which("aplay") and os.path.exists(wav):
            print("       playing test chime..."); subprocess.run(["aplay", "-q", wav])
        else: say("WARN", "cannot play test sound (aplay or sfx missing)")
    return finish()

def finish():
    print(f"\n{count['OK']} ok, {count['WARN']} warnings, {count['FAIL']} failures")
    if count["FAIL"]: print("Fix the FAIL lines first.")
    return 1 if count["FAIL"] else 0

if __name__ == "__main__":
    sys.exit(main())
