#!/usr/bin/env python3
"""Generate the (non-voice) sound effects: soft chimes. Needs numpy. Released CC0."""
import os, wave
import numpy as np
RATE = 22050
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..",
                   "config/includes.chroot/usr/local/lib/kidsos/activities/abc-letters/sfx")

def note(freq, dur, vol=0.35):
    t = np.arange(int(RATE * dur)) / RATE
    env = np.minimum(1, t / 0.01) * np.exp(-t * 5.5)
    return vol * env * (np.sin(2*np.pi*freq*t) + 0.3*np.sin(2*np.pi*freq*2*t))

def seq(freqs, dur=0.18, gap=0.02):
    return np.concatenate([np.concatenate([note(f, dur), np.zeros(int(RATE*gap))]) for f in freqs])

def save(name, data):
    os.makedirs(OUT, exist_ok=True)
    pcm = (np.clip(data, -1, 1) * 32767).astype("<i2")
    with wave.open(os.path.join(OUT, name + ".wav"), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(RATE); w.writeframes(pcm.tobytes())

save("tap",     note(660, 0.08, 0.25))
save("correct", seq([523.25, 659.25, 783.99], 0.16))                 # C E G, rising
save("cheer",   seq([523.25, 659.25, 783.99, 1046.5, 783.99, 1046.5], 0.14))
print("sfx written")
