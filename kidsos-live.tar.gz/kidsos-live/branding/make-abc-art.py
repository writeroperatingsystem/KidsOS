#!/usr/bin/env python3
"""Draw the 26 ABC pictures (flat sticker style, 512x512 transparent PNG). Needs Pillow.
Own artwork: released CC0. Edit and re-run to change any picture."""
import math, os
from PIL import Image, ImageDraw

SS = 3; N = 512
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..",
                   "config/includes.chroot/usr/local/lib/kidsos/activities/abc-letters/images")
INK = (45, 52, 80)
RED=(231,76,60); DRED=(176,52,42); ORG=(243,156,18); YEL=(247,208,60); GRN=(46,204,113); DGRN=(30,140,80)
BLU=(52,152,219); DBLU=(30,100,160); PUR=(155,89,182); PINK=(255,170,190); DPINK=(240,120,150)
BRN=(160,105,60); DBRN=(110,70,40); WHT=(255,255,255); GRY=(190,196,204); BLK=(45,45,50)
SKY=(200,230,250); CREAM=(255,243,205); TAN=(222,176,120); ICE=(225,242,252)

class Pic:
    def __init__(self):
        self.im = Image.new("RGBA", (N*SS, N*SS), (0,0,0,0)); self.d = ImageDraw.Draw(self.im)
    def s(self, v): return [x*SS for x in v] if isinstance(v,(list,tuple)) else v*SS
    def ell(self,cx,cy,rx,ry,fill,out=INK,w=7):
        self.d.ellipse(self.s((cx-rx,cy-ry,cx+rx,cy+ry)),fill=fill,outline=out if out else None,width=w*SS)
    def rect(self,x0,y0,x1,y1,fill,out=INK,w=7,r=0):
        if r: self.d.rounded_rectangle(self.s((x0,y0,x1,y1)),radius=r*SS,fill=fill,outline=out if out else None,width=w*SS)
        else: self.d.rectangle(self.s((x0,y0,x1,y1)),fill=fill,outline=out if out else None,width=w*SS)
    def poly(self,pts,fill,out=INK,w=7):
        p=[(x*SS,y*SS) for x,y in pts]; self.d.polygon(p,fill=fill)
        if out: self.d.line(p+[p[0]],fill=out,width=w*SS,joint="curve")
    def line(self,pts,fill=INK,w=7):
        p=[(x*SS,y*SS) for x,y in pts]; self.d.line(p,fill=fill,width=w*SS,joint="curve")
        for x,y in (p[0],p[-1]):
            r=w*SS/2; self.d.ellipse((x-r,y-r,x+r,y+r),fill=fill)
    def pie(self,box,a0,a1,fill,out=INK,w=7):
        self.d.pieslice(self.s(box),a0,a1,fill=fill,outline=out if out else None,width=w*SS)
    def arc(self,box,a0,a1,fill=INK,w=7): self.d.arc(self.s(box),a0,a1,fill=fill,width=w*SS)
    def eye(self,cx,cy,r=15):
        self.ell(cx,cy,r,r*1.15,BLK,out=None); self.ell(cx-r*.3,cy-r*.4,r*.35,r*.35,WHT,out=None)
    def star(self,cx,cy,r,fill=YEL):
        pts=[(cx+(r if i%2==0 else r*.45)*math.sin(i*math.pi/5),cy-(r if i%2==0 else r*.45)*math.cos(i*math.pi/5)) for i in range(10)]
        self.poly(pts,fill,w=5)
    def clipped(self, mask_ell, draw):
        """draw(layer) onto a fresh layer, then keep only the part inside the ellipse."""
        lay=Pic(); draw(lay)
        mask=Image.new("L",self.im.size,0); ImageDraw.Draw(mask).ellipse(self.s(mask_ell),fill=255)
        lay.im.putalpha(Image.composite(lay.im.getchannel("A"),Image.new("L",self.im.size,0),mask))
        self.im.alpha_composite(lay.im)
    def save(self,name):
        os.makedirs(OUT,exist_ok=True)
        self.im.resize((N,N),Image.LANCZOS).save(os.path.join(OUT,name+".png"))

def a():
    p=Pic(); p.line([(256,185),(272,105)],DBRN,16)
    p.poly([(278,130),(345,92),(392,128),(335,158)],GRN)
    p.ell(256,300,155,140,RED); p.ell(256,175,30,16,RED,out=None); p.ell(198,262,20,38,(255,150,140),out=None); p.save("a")
def b():
    p=Pic(); box=(86,86,426,426); cols=[RED,YEL,BLU,RED,YEL,BLU]
    for i,c in enumerate(cols): p.pie(box,i*60-90,i*60-30,c,out=None)
    p.ell(256,256,170,170,None,INK,8); p.ell(256,256,34,34,WHT); p.ell(185,180,26,16,WHT,out=None); p.save("b")
def c():
    p=Pic()
    for sx in (1,-1):
        p.poly([(256+sx*126,235),(256+sx*118,100),(256+sx*32,175)],ORG); p.poly([(256+sx*104,200),(256+sx*100,140),(256+sx*62,178)],PINK,out=None)
    p.ell(256,295,152,125,ORG); p.ell(256,345,58,40,CREAM,out=None)
    p.eye(205,280,17); p.eye(307,280,17); p.poly([(240,320),(272,320),(256,338)],DPINK,w=4)
    p.arc((226,332,256,360),0,180,INK,5); p.arc((256,332,286,360),0,180,INK,5)
    for sy in (-12,0,12):
        p.line([(185,345+sy),(110,335+sy*2)],INK,4); p.line([(327,345+sy),(402,335+sy*2)],INK,4)
    p.save("c")
def d():
    p=Pic()
    for sx in (1,-1): p.ell(256+sx*135,285,44,98,DBRN)
    p.ell(256,285,135,125,TAN); p.ell(256,345,72,52,CREAM,out=None); p.ell(256,320,28,19,BLK,out=None)
    p.eye(205,265,17); p.eye(307,265,17); p.rect(240,368,272,420,DPINK,r=14); p.line([(256,352),(256,372)],INK,5); p.save("d")
def e():
    p=Pic(); p.ell(256,285,118,155,CREAM)
    for x,y in ((215,230),(300,260),(240,340),(310,350),(200,310)): p.ell(x,y,7,5,TAN,out=None)
    p.ell(205,215,20,38,WHT,out=None); p.save("e")
def f():
    p=Pic(); p.poly([(370,262),(468,172),(468,352)],ORG); p.poly([(205,180),(262,115),(305,190)],ORG)
    p.ell(235,262,150,98,ORG); p.arc((90,205,200,320),270,90,DRED,8)
    for x in (265,305,345): p.arc((x-30,215,x+30,310),300,60,DRED,7)
    p.ell(160,242,19,19,WHT); p.ell(163,244,9,9,BLK,out=None); p.arc((120,275,170,305),20,100,INK,5)
    for x,y,r in ((88,150,13),(62,105,9),(112,95,7)): p.ell(x,y,r,r,SKY,BLU,4)
    p.save("f")
def g():
    p=Pic(); p.line([(256,150),(262,90)],DBRN,14); p.poly([(266,100),(340,75),(380,115),(315,140)],GRN)
    for x,y in ((170,200),(256,200),(342,200),(213,272),(299,272),(256,344)):
        p.ell(x,y,48,48,PUR); p.ell(x-16,y-17,11,8,(215,170,235),out=None)
    p.save("g")
def h():
    p=Pic(); p.ell(256,345,205,55,TAN); p.rect(158,160,354,345,TAN,out=None); p.line([(158,345),(158,175)],INK,7); p.line([(354,345),(354,175)],INK,7)
    p.ell(256,175,98,30,(240,205,150)); p.rect(158,270,354,320,RED,out=None); p.line([(158,270),(354,270)],INK,6); p.line([(158,320),(354,320)],INK,6)
    p.arc((51,290,461,400),20,160,INK,7); p.save("h")
def i():
    p=Pic(); p.pie((56,150,456,550),180,360,ICE); p.rect(40,349,472,375,WHT,out=None)
    for y,dx in ((235,165),(290,195)): p.line([(256-dx,y),(256+dx,y)],GRY,5)
    for x,y0,y1 in ((200,185,235),(312,185,235),(256,235,290),(160,235,290),(352,235,290),(200,290,330),(312,290,330)): p.line([(x,y0),(x,y1)],GRY,5)
    p.pie((56,150,456,550),180,360,None,INK,8); p.pie((211,285,301,375),180,360,(70,100,140),INK,6); p.rect(211,330,301,349,(70,100,140),out=None); p.line([(211,330),(211,349)],INK,6); p.line([(301,330),(301,349)],INK,6)
    p.save("i")
def j():
    p=Pic()
    for k,x in enumerate((165,215,265,315,365)):
        pts=[(x+14*math.sin(t/3+k),250+t*3.4) for t in range(0,60)]; p.line(pts,PUR if k%2 else (190,120,210),13)
    p.pie((86,80,426,420),180,360,(215,150,235)); p.pie((86,80,426,420),180,360,None,INK,8); p.rect(86,246,426,262,(215,150,235),out=None); p.line([(86,252),(426,252)],INK,7)
    for x,y in ((200,160),(290,140),(340,200),(150,200)): p.ell(x,y,13,13,WHT,out=None)
    p.eye(210,225,12); p.eye(302,225,12); p.save("j")
def k():
    p=Pic(); c=(256,195); pts=[(256,55),(385,195),(256,345),(127,195)]; cols=[RED,YEL,GRN,BLU]
    for n in range(4): p.poly([pts[n],pts[(n+1)%4],c],cols[n],out=None)
    p.poly(pts,None,INK,8); p.line([pts[0],pts[2]],INK,5); p.line([pts[1],pts[3]],INK,5)
    path=[(256+30*math.sin(t/4),345+t*2.2) for t in range(0,56)]; p.line(path,INK,6)
    for t,col in ((14,RED),(30,YEL),(46,BLU)): x,y=path[t]; p.poly([(x-22,y-14),(x+22,y-14),(x,y+14)],col,w=5)
    p.save("k")
def l():
    p=Pic()
    for t in range(14):
        a=t*2*math.pi/14; p.ell(256+150*math.cos(a),270+150*math.sin(a),50,50,(205,125,40))
    p.ell(256,270,170,170,(205,125,40),out=None)
    p.ell(256,282,115,110,YEL); p.ell(256,320,50,36,CREAM,out=None)
    for sx in (1,-1): p.ell(256+sx*90,170,26,26,(205,125,40))
    p.eye(215,262,15); p.eye(297,262,15); p.poly([(240,298),(272,298),(256,316)],BRN,w=4); p.arc((226,308,256,336),0,180,INK,5); p.arc((256,308,286,336),0,180,INK,5); p.save("l")
def m():
    from PIL import ImageChops
    p=Pic()
    def disc(cx,cy,r):
        m_=Image.new("L",p.im.size,0); ImageDraw.Draw(m_).ellipse(p.s((cx-r,cy-r,cx+r,cy+r)),fill=255); return m_
    body=ImageChops.subtract(disc(200,256,170),disc(305,245,160))
    edge=ImageChops.subtract(disc(200,256,178),disc(305,245,152))   # slightly fatter = outline
    p.im.paste(Image.new("RGBA",p.im.size,INK+(255,)),(0,0),edge)
    p.im.paste(Image.new("RGBA",p.im.size,YEL+(255,)),(0,0),body)
    p.ell(70,250,15,11,(235,185,40),out=None); p.ell(105,345,11,8,(235,185,40),out=None)
    for x,y,r in ((400,140,34),(450,330,24),(330,420,20)): p.star(x,y,r)
    p.save("m")
def n():
    p=Pic()
    for x,y in ((190,290),(262,265),(334,292)): p.ell(x,y,40,52,(175,225,245),BLU,6)
    p.pie((50,210,462,470),0,180,BRN)
    for a0 in range(10,180,18): p.line([(256+190*math.cos(math.radians(a0)),340+110*math.sin(math.radians(a0))),(256+120*math.cos(math.radians(a0+25)),340+60*math.sin(math.radians(a0+25)))],DBRN,6)
    p.pie((50,210,462,470),0,180,None,INK,8); p.line([(50,340),(462,340)],INK,8); p.save("n")
def o():
    p=Pic(); p.ell(256,292,165,158,ORG)
    for x,y in ((190,250),(260,235),(330,260),(215,330),(300,345),(250,285),(350,330)): p.ell(x,y,5,5,(215,125,10),out=None)
    p.ell(190,240,24,38,(255,200,100),out=None); p.line([(256,138),(256,105)],DBRN,12); p.poly([(262,118),(338,80),(370,130),(300,150)],GRN); p.save("o")
def pg():
    p=Pic()
    for sx in (1,-1): p.poly([(256+sx*135,215),(256+sx*118,95),(256+sx*30,150)],DPINK)
    p.ell(256,275,170,150,PINK); p.ell(256,330,76,54,DPINK); p.ell(232,330,11,17,DRED,out=None); p.ell(280,330,11,17,DRED,out=None)
    p.eye(190,250,17); p.eye(322,250,17); p.save("p")
def q():
    p=Pic(); x0,y0,cs=88,88,84; cols=[RED,YEL,BLU,GRN,PUR,ORG]
    p.rect(x0-14,y0-14,x0+4*cs+14,y0+4*cs+14,CREAM,r=14)
    for r in range(4):
        for c_ in range(4): p.rect(x0+c_*cs+4,y0+r*cs+4,x0+(c_+1)*cs-4,y0+(r+1)*cs-4,cols[(r*2+c_)%6],out=None,r=6)
    for t in range(1,4): p.line([(x0+t*cs,y0),(x0+t*cs,y0+4*cs)],WHT,3); p.line([(x0,y0+t*cs),(x0+4*cs,y0+t*cs)],WHT,3)
    p.rect(x0-14,y0-14,x0+4*cs+14,y0+4*cs+14,None,INK,8,r=14); p.save("q")
def r():
    p=Pic(); cols=[RED,ORG,YEL,GRN,BLU,PUR]; cx,cy=256,370
    for k,col in enumerate(cols): R=230-k*30; p.pie((cx-R,cy-R,cx+R,cy+R),180,360,col,out=None)
    p.pie((cx-50,cy-50,cx+50,cy+50),180,360,(0,0,0,0),out=None)
    p.arc((26,140,486,600),180,360,INK,8); p.arc((cx-50,cy-50,cx+50,cy+50),180,360,INK,8)
    for x in (68,444):
        p.ell(x,380,48,34,WHT); p.ell(x-40,392,32,24,WHT); p.ell(x+40,392,32,24,WHT); p.rect(x-72,392,x+72,420,WHT,out=None)
    p.save("r")
def s():
    p=Pic()
    for t in range(12):
        a=t*math.pi/6; p.poly([(256+112*math.cos(a-.17),256+112*math.sin(a-.17)),(256+196*math.cos(a),256+196*math.sin(a)),(256+112*math.cos(a+.17),256+112*math.sin(a+.17))],ORG,w=5)
    p.ell(256,256,118,118,YEL); p.eye(215,235,14); p.eye(297,235,14); p.arc((200,235,312,320),20,160,INK,8)
    p.ell(190,285,16,10,(255,170,120),out=None); p.ell(322,285,16,10,(255,170,120),out=None); p.save("s")
def t():
    p=Pic(); p.rect(222,290,290,462,BRN,r=10)
    for x,y,R in ((256,185,112),(170,275,90),(342,275,90)): p.ell(x,y,R,R,GRN)
    p.ell(256,230,100,90,GRN,out=None)
    for x,y in ((220,190),(300,230),(160,285),(350,290)): p.ell(x,y,14,14,RED,DRED,4)
    p.save("t")
def u():
    p=Pic(); cols=[RED,WHT,RED,WHT]
    for k,col in enumerate(cols): p.pie((46,90,466,510),180+k*45,225+k*45,col,out=None)
    p.pie((46,90,466,510),180,360,None,INK,8); p.line([(46,300),(466,300)],INK,7)
    p.line([(256,300),(256,430)],DBRN,16); p.arc((206,405,256,465),0,180,DBRN,16); p.line([(256,300),(256,70)],DBRN,14); p.save("u")
def v():
    p=Pic(); p.poly([(50,150),(330,150),(400,235),(465,255),(465,355),(50,355)],GRN)
    p.poly([(340,172),(382,235),(310,235),(310,172)],SKY); p.rect(80,185,150,245,SKY,r=8); p.rect(172,185,242,245,SKY,r=8)
    for x in (150,372): p.ell(x,365,50,50,BLK); p.ell(x,365,22,22,GRY,out=None)
    p.ell(458,290,10,10,YEL,out=None); p.save("v")
def w():
    p=Pic(); p.poly([(395,275),(440,185),(485,215),(455,285),(495,330),(430,335)],BLU)
    p.ell(240,300,200,125,BLU); p.ell(235,345,155,75,SKY,out=None); p.arc((40,175,440,425),10,170,INK,8)
    p.eye(135,265,15); p.arc((60,300,170,350),10,80,INK,5)
    for dx in (-1,1): p.line([(180,180),(180+dx*35,125),(180+dx*70,140)],(120,200,245),9)
    p.ell(145,100,10,10,SKY,BLU,4); p.ell(250,110,10,10,SKY,BLU,4); p.save("w")
def x():
    p=Pic(); p.poly([(90,205),(160,135),(410,135),(340,205)],(230,185,125)); p.poly([(340,205),(410,135),(410,370),(340,440)],(185,135,80))
    p.rect(90,205,340,440,TAN); p.line([(190,205),(190,260)],(230,200,140),22)
    p.line([(135,250),(295,400)],RED,34); p.line([(295,250),(135,400)],RED,34); p.save("x")
def y():
    p=Pic(); p.line([(256,30),(256,230)],GRY,8); p.ell(256,46,24,24,None,INK,7)
    p.ell(256,335,140,140,RED); p.ell(256,335,92,92,YEL); p.ell(256,335,36,36,DRED); p.ell(205,285,26,40,(255,150,140),out=None); p.save("y")
def z():
    p=Pic()
    for sx in (1,-1): p.poly([(256+sx*100,130),(256+sx*130,40),(256+sx*50,95)],WHT); p.poly([(256+sx*92,110),(256+sx*118,60),(256+sx*68,96)],DPINK,out=None)
    p.ell(256,265,118,160,WHT)
    def stripes(L):
        for k in range(-1,7): y0=95+k*52; L.poly([(120,y0+10),(392,y0-14),(392,y0+10),(120,y0+34)],BLK,out=None)
    p.clipped((138,105,374,425),stripes)
    p.ell(256,265,118,160,None,INK,8)
    p.ell(256,380,78,56,GRY); p.ell(232,385,10,16,BLK,out=None); p.ell(280,385,10,16,BLK,out=None)
    p.eye(200,230,17); p.eye(312,230,17); p.save("z")

if __name__=="__main__":
    for fn in (a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,pg,q,r,s,t,u,v,w,x,y,z): fn()
    # contact sheet for review
    from glob import glob
    files=sorted(glob(os.path.join(OUT,"*.png"))); cs=Image.new("RGB",(7*200,4*200),(245,250,255))
    for n_,f_ in enumerate(files):
        im=Image.open(f_).resize((190,190),Image.LANCZOS); cs.paste(im,((n_%7)*200+5,(n_//7)*200+5),im)
    cs.save(os.path.join(os.path.dirname(os.path.abspath(__file__)),"abc-contact-sheet.png")); print(len(files),"images")
