#!/usr/bin/env python3
"""Layout mockup of the ABC activity (Pillow, using the app's real rectangle maths). NOT a screenshot."""
import sys, os
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..")
sys.path.insert(0, os.path.join(ROOT, "tests")); import fake_pygame as fp; fp.install()
A = os.path.join(ROOT, "config/includes.chroot/usr/local/lib/kidsos/activities/abc-letters"); sys.path.insert(0, A)
import main as m
from logic import BY_LETTER
from PIL import Image, ImageDraw, ImageFont
W, H = 1366, 768; app = m.App((W, H)); FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
F = lambda sz: ImageFont.truetype(FONT, int(sz))
def card(d, r, col, rad):
    o = max(3, r.h // 28); d.rounded_rectangle((r.x, r.y + o, r.right, r.bottom + o), rad, fill=tuple(max(0, c - 55) for c in col)); d.rounded_rectangle((r.x, r.y, r.right, r.bottom), rad, fill=col)
def btn(d, r, col, sym): card(d, r, col, r.h // 4); d.text(r.center, sym, font=F(r.h * .5), fill="white", anchor="mm")
def pic(im, d, r, l):
    card(d, r, (245, 250, 255), r.h // 10); s = int(min(r.w, r.h) * .86)
    p = Image.open(f"{A}/images/{l}.png").resize((s, s), Image.LANCZOS); im.paste(p, (r.centerx - s // 2, r.centery - s // 2), p)
def tile(d, r, it):
    card(d, r, it.color, r.h // 8); t = it.letter.upper() + it.letter; sz = r.h * .62
    while F(sz).getlength(t) > r.w * .86: sz *= .93
    d.text((r.centerx, r.centery - sz * .04), t, font=F(sz), fill="white", anchor="mm")
im1 = Image.new("RGB", (W, H), (27, 108, 168)); d = ImageDraw.Draw(im1)
btn(d, app.home_r, (241, 196, 15), "⌂"); btn(d, app.mode_r, (39, 174, 96), "★"); tile(d, app.letter_r, BY_LETTER["b"]); pic(im1, d, app.pic_r, "b")
d.text((app.pic_r.centerx, app.pic_r.bottom - H * .06), "ball", font=F(H * .06), fill=(45, 52, 80), anchor="mm")
btn(d, app.prev_r, (230, 126, 34), "◀"); btn(d, app.next_r, (230, 126, 34), "▶")
im2 = Image.new("RGB", (W, H), (27, 108, 168)); d = ImageDraw.Draw(im2)
btn(d, app.home_r, (241, 196, 15), "⌂"); btn(d, app.mode_r, (142, 68, 173), "▤"); tile(d, app.tile_r, BY_LETTER["c"])
for k in range(8):
    x = W // 2 + (k - 3.5) * H * .05; r_ = H * .022 if k < 3 else H * .012
    d.ellipse((x - r_, app.dots_y - r_, x + r_, app.dots_y + r_), fill=(241, 196, 15) if k < 3 else "white")
for r, l in zip(app.choice_r, "dcs"): pic(im2, d, r, l)
out = Image.new("RGB", (W, H * 2 + 20)); out.paste(im1, (0, 0)); out.paste(im2, (0, H + 20))
out.resize((W // 2, (H * 2 + 20) // 2)).save(os.path.join(HERE, "abc-layout-mockup.png")); print("mockup ok")
