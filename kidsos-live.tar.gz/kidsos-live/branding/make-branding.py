#!/usr/bin/env python3
"""Generate all KidsOS branding images (needs Pillow). Re-run after editing.

Outputs (committed into the tree so the build needs no image tools):
  config/includes.chroot/usr/share/plymouth/themes/kidsos/{logo,dot-red,dot-yellow,dot-green}.png
  config/includes.chroot/usr/share/kidsos/{grub-bg.png}
  config/includes.binary/isolinux/splash.png   (640x480)
  branding/preview-*.png
"""
import os
from PIL import Image, ImageDraw

BG = (27, 108, 168)           # same blue as the launcher
RED, YEL, GRN, WHITE = (231, 76, 60), (241, 196, 15), (46, 204, 113), (255, 255, 255)
SS = 4                        # supersampling factor
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")

def out(path):
    p = os.path.join(ROOT, path); os.makedirs(os.path.dirname(p), exist_ok=True); return p

def tile(color, glyph, size=190, angle=0):
    """Rounded colored tile with a white shape glyph; returns RGBA."""
    s = size * SS
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, s - 1, s - 1), radius=int(s * .24), fill=color)
    # soft inner highlight
    d.rounded_rectangle((s * .06, s * .05, s * .94, s * .45), radius=int(s * .2), fill=tuple(min(255, c + 22) for c in color))
    c = s // 2; r = int(s * .26)
    if glyph == "circle":
        d.ellipse((c - r, c - r, c + r, c + r), fill=WHITE)
    elif glyph == "triangle":
        d.polygon([(c, c - r * 1.1), (c - r * 1.15, c + r * .9), (c + r * 1.15, c + r * .9)], fill=WHITE)
    elif glyph == "square":
        d.rounded_rectangle((c - r, c - r, c + r, c + r), radius=int(r * .2), fill=WHITE)
    if angle: im = im.rotate(angle, resample=Image.BICUBIC, expand=True)
    return im

def logo(w=720, h=400):
    """Three tilted blocks (circle / triangle / square) with a smile underneath."""
    s = Image.new("RGBA", (w * SS, h * SS), (0, 0, 0, 0))
    spec = [(RED, "circle", 7), (YEL, "triangle", -4), (GRN, "square", 6)]
    for i, (col, g, ang) in enumerate(spec):
        t = tile(col, g, 190, ang)
        x = (40 + i * 230) * SS - (t.width - 190 * SS) // 2
        y = 20 * SS - (t.height - 190 * SS) // 2 + (12 * SS if i == 1 else 0)
        # drop shadow
        sh = Image.new("RGBA", t.size, (0, 0, 0, 0))
        sh.paste((0, 0, 0, 55), mask=t.split()[3])
        s.alpha_composite(sh, (x + 6 * SS, y + 10 * SS)); s.alpha_composite(t, (x, y))
    d = ImageDraw.Draw(s)
    # smile: dense circles along an ellipse arc = uniform stroke with round caps
    import math
    cx, cy, rx, ry, r = 360 * SS, 255 * SS, 160 * SS, 90 * SS, 11 * SS
    for i in range(0, 401):
        ang = math.radians(25 + 130 * i / 400)
        px, py = cx + rx * math.cos(ang), cy + ry * math.sin(ang)
        d.ellipse((px - r, py - r, px + r, py + r), fill=WHITE)
    return s.resize((w, h), Image.LANCZOS)

def dot(color, size=64):
    s = size * SS
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.ellipse((2 * SS, 2 * SS, s - 2 * SS, s - 2 * SS), fill=color)
    return im.resize((size, size), Image.LANCZOS)

def background(w, h, logo_img, logo_frac=.52):
    ov = Image.new("RGBA", (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(ov)
    for cx, cy, r, a in ((.12, .18, .28, 22), (.9, .85, .34, 22), (.85, .1, .16, 18)):
        d.ellipse((w * cx - h * r, h * cy - h * r, w * cx + h * r, h * cy + h * r), fill=(255, 255, 255, a))
    bg = Image.new("RGBA", (w, h), BG + (255,)); bg.alpha_composite(ov)
    lw = int(w * logo_frac); lh = int(lw * logo_img.height / logo_img.width)
    bg.alpha_composite(logo_img.resize((lw, lh), Image.LANCZOS), ((w - lw) // 2, int(h * .5 - lh / 2)))
    return bg.convert("RGB")

L = logo()
pl = "config/includes.chroot/usr/share/plymouth/themes/kidsos/"
L.save(out(pl + "logo.png"))
for n, c in (("red", RED), ("yellow", YEL), ("green", GRN)):
    dot(c).save(out(pl + f"dot-{n}.png"))
background(640, 480, L).save(out("config/includes.binary/isolinux/splash.png"))
background(1024, 768, L).save(out("config/includes.chroot/usr/share/kidsos/grub-bg.png"))
background(1280, 720, L).save(out("branding/preview-16x9.png"))
print("branding generated")
