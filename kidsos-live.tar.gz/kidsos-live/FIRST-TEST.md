# ABC – first real-hardware test (step by step)

**Goal:** see ABC run on a real screen with real audio, and bring back logs if anything is wrong.
**Be ready for surprises:** this is the first time the ABC screen has run outside my test harness. It is built to fail
safely (errors go to a log and you return to the launcher), so a problem is useful information, not a disaster.

**The sounds are placeholders.** There is no recorded voice yet, so you will hear *beeps*, not speech:

| You do this | You should hear |
|---|---|
| Tap the big letter | one beep (higher for later letters) |
| Tap the picture / arrive on a letter | beep, then 1–4 quick blips (longer word = more blips) |
| Start Match | two rising notes, then one beep |
| Tap a wrong picture | blips, then two falling notes |
| Tap the right picture | chime, blips, then a double-beep "ta-da" |
| Finish all 8 rounds | fanfare |

(Beeps prove playback, order and timing work. They can't prove the *right word* plays. For that, optionally run
`tools/make-placeholder-audio.py --espeak` on your PC first (needs `sudo apt install espeak-ng`): robot voice instead of beeps.)

---

## Step 1 – Quick check on any Debian/Ubuntu PC (≈10 minutes)  ← do this first

Any ordinary Linux PC with a screen and speakers is fine. It needs internet once, to install pygame.

1. Copy `kidsos-live.tar.gz` to the PC and open a terminal there:
   ```
   tar xzf kidsos-live.tar.gz
   cd kidsos-live
   ```
2. Install ABC (installs `python3-pygame` and the Comic Neue font, copies the files, runs a self-check):
   ```
   sudo tools/install-abc.sh
   ```
   Read the self-check. `[  OK ]` is good, `[WARN]` is fine to ignore for now, `[FAIL]` must be fixed (it tells you how).
   `WARN … PLACEHOLDER tones` is expected.
3. Run it in a window:
   ```
   kidsos-abc --window
   ```
4. Go through the **checklist at the bottom**. Close with the yellow house button.
5. Optional: play a test chime to check speakers: `kidsos-abc --check --sound`

If step 1 works, ABC itself is fine and any later problem is about the KidsOS image or the laptop.

---

## Step 2 – On the real KidsOS laptop, from the pendrive

### 2a. Build the pendrive (on a Debian/Ubuntu PC with internet)
1. `sudo ./build.sh`   (first build takes a long time; the image build has never been run, so if it stops, keep `build.log` and send it to me)
2. Find your pendrive: `lsblk` (look for the right size; it will be something like `/dev/sdb`). **Triple-check, this erases it.**
3. `sudo tools/make-usb.sh kidsos-0.1-amd64.iso /dev/sdX`  (4 GB or bigger)

### 2b. Boot the laptop
1. Plug the pendrive into the old laptop, switch it on, and open its boot menu (usually **F12**, **Esc** or **F2**). Choose the USB stick.
2. Wait. You should see: **logo screen → bouncing coloured dots → six big buttons.**
   If the screen stays black or garbled: switch off, boot again, and as soon as the logo appears press any key (or **Esc** on UEFI laptops)
   and choose **KidsOS - safe graphics**.
3. Tap the red **ABC** button. Go through the **checklist below**.
4. Switch off: leave ABC with the house button, then **hold the small grey button (bottom-right) for 5 seconds**.

### 2c. Get the logs back (always do this, even if everything worked)
1. Plug the pendrive into your PC. Your file manager mounts a partition called **persistence**, normally at `/media/<you>/persistence`.
2. ```
   tools/push-to-pendrive.sh /media/$USER/persistence --logs
   ```
   This copies the logs into a new folder `kidsos-logs-<date>`. The useful files are:
   `abc.log` (what ABC did), `launcher.log` (launch failures), `hardware.txt` (laptop, graphics and sound card), `Xorg.0.log` (graphics).
3. Send me that folder together with the laptop model, the symptoms, and which checklist lines failed.

### Changing ABC later without rebuilding
Edit files in the project, plug the pendrive into your PC, and run
`tools/push-to-pendrive.sh /media/$USER/persistence`, then boot the laptop again. (The pendrive prefers this copy over the built-in
one. `… --remove` goes back to the built-in ABC.)

---

## Alternative 2 – if the image won't build or boot
Use the stock Debian *Live* ISO (any desktop; download from debian.org) on the old laptop instead. Boot it, connect to the internet,
copy the `kidsos-live` folder over (second USB stick), open a terminal there and do **Step 1**. This tests the laptop's screen,
audio, speed and 1 GB of RAM with ABC, without the KidsOS image.

---

## Checklist (tick as you go)
- [ ] ABC opens full-screen within about 3 seconds of tapping the button
- [ ] I see a big **Bb**/**Aa** tile and a big picture; the picture is clear, not blurry
- [ ] Tapping the letter and the picture each make a sound (see the table above)
- [ ] Orange arrows change the letter; going past **Z** wraps to **A**
- [ ] Typing a letter key (e.g. **m**) jumps to that letter
- [ ] Green star → Match: a big letter on top, three pictures, 8 white dots
- [ ] Wrong picture: it shakes, you hear blips + falling notes, nothing bad happens
- [ ] After two wrong taps the right picture blinks yellow
- [ ] Right picture: chime, then it moves to the next round by itself
- [ ] After round 8: stars, confetti, fanfare, and three working buttons (again / learn / home)
- [ ] Yellow house button returns to the six-button launcher (also **Esc** on a keyboard)
- [ ] 10 minutes of tapping around: no freeze, no crash, no growing lag

Please also note: laptop model, screen size, how long ABC takes to open, any stutter, and whether touch/trackpad taps feel reliable.

---

## If something goes wrong
| Symptom | What to look at |
|---|---|
| ABC button does nothing / returns at once | `launcher.log` and `abc.log` on the pendrive (`KidsOS-logs`) |
| ABC freezes or looks wrong | `abc.log`: it records errors and a start-up summary (screen, fonts, audio, voice counts) |
| No sound | `abc.log` line "audio ready" or "audio init failed"; `hardware.txt` should list a sound card under `aplay -l` |
| Letters look odd (two-storey **a**) | `abc.log` line `font:`; ideal is Comic Neue |
| Black screen before the launcher | `Xorg.0.log`; retry with **KidsOS - safe graphics** |
| Slow | note the laptop model and RAM from `hardware.txt` |

ABC never needs the network, and nothing in it can reach one.
