#!/usr/bin/env python3
"""Create PLACEHOLDER audio in activities/abc-letters/voice-placeholder/ so the whole activity can be tested
before real voice exists. Standard library only.

  tools/make-placeholder-audio.py            musical tones (NOT speech): tests playback, order and timing
  tools/make-placeholder-audio.py --espeak   robot voice (needs espeak-ng): also tests that the right word plays

Placeholders are only used where no real clip exists in voice/, so recording over them is automatic."""
import math, os, shutil, struct, subprocess, sys, wave
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config/includes.chroot/usr/local/lib/kidsos/activities/abc-letters")
sys.path.insert(0, ROOT)
from logic import voice_clips, BY_LETTER
RATE = 22050
OUT = os.path.join(ROOT, "voice-placeholder")

def hz(semi): return 220.0 * 2 ** (semi / 12)

def tone(freq, dur, shape="sine", vol=.35):
    n = int(RATE * dur); out = []
    for i in range(n):
        t = i / RATE; ph = (t * freq) % 1
        w = math.sin(2 * math.pi * ph) if shape == "sine" else (4 * abs(ph - .5) - 1 if shape == "tri" else (1 if ph < .5 else -1) * .6)
        env = min(1, t / .01, (dur - t) / .06)
        out.append(vol * env * w)
    return out

def gap(d): return [0.0] * int(RATE * d)

def write(path, samples):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(RATE)
        w.writeframes(b"".join(struct.pack("<h", int(max(-1, min(1, s)) * 32767)) for s in samples))

def make_tone(rel):
    kind, key = rel.split("/")
    if kind == "letters":                     # one steady beep; pitch rises a→z
        return tone(hz("abcdefghijklmnopqrstuvwxyz".index(key)), .40)
    if kind == "words":                       # 'bip-bop' blips: more blips for longer words
        n = max(1, min(4, round(len(BY_LETTER[key].word) / 3))); base = "abcdefghijklmnopqrstuvwxyz".index(key)
        s = []
        for k in range(n): s += tone(hz(base + (7 if k % 2 else 0)), .16, "tri") + gap(.05)
        return s
    return {"which": tone(hz(12), .2, "tri") + gap(.05) + tone(hz(19), .35, "tri"),                      # question: rises
            "yes": tone(hz(24), .12, "sq", .25) + gap(.05) + tone(hz(24), .12, "sq", .25) + gap(.05) + tone(hz(28), .3, "sq", .25),
            "try_again": tone(hz(10), .22, "tri") + gap(.04) + tone(hz(5), .35, "tri"),                  # falls, soft
            "done": sum([tone(hz(s), .14, "tri") + gap(.02) for s in (12, 16, 19, 24)], []) + tone(hz(28), .5, "tri")}[key]

def make_espeak(rel, text):
    spoken = {"a": "ah", "b": "buh", "c": "kuh", "d": "duh", "e": "eh", "f": "fff", "g": "guh", "h": "huh", "i": "ih", "j": "juh",
              "k": "kuh", "l": "lll", "m": "mmm", "n": "nnn", "o": "aw", "p": "puh", "q": "kwuh", "r": "rrr", "s": "sss",
              "t": "tuh", "u": "uh", "v": "vvv", "w": "wuh", "x": "ks", "y": "yuh", "z": "zzz"}
    say = spoken[rel.split("/")[1]] if rel.startswith("letters/") else text
    dst = os.path.join(OUT, rel + ".wav"); os.makedirs(os.path.dirname(dst), exist_ok=True)
    subprocess.run(["espeak-ng", "-v", "en-us", "-s", "110", "-w", dst, say], check=True)

use_espeak = "--espeak" in sys.argv
if use_espeak and not shutil.which("espeak-ng"): sys.exit("espeak-ng not found (sudo apt install espeak-ng)")
for rel, text, _ in voice_clips():
    if use_espeak: make_espeak(rel, text)
    else: write(os.path.join(OUT, rel + ".wav"), make_tone(rel))
print(f"{len(voice_clips())} placeholder clips in {os.path.normpath(OUT)} ({'robot voice' if use_espeak else 'tones, not speech'})")
