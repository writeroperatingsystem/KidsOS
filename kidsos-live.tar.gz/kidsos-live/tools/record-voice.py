#!/usr/bin/env python3
"""Guided recording of the ABC voice clips (needs ALSA: arecord + aplay; ffmpeg optional for clean-up).

  tools/record-voice.py --status          what is recorded / missing
  tools/record-voice.py                   record every MISSING clip, one by one
  tools/record-voice.py --all             re-record everything
  tools/record-voice.py --only letters    letters | words | prompts
  tools/record-voice.py --clean           trim silence + level all existing clips (needs ffmpeg)

Tips: quiet room, mic 15 cm away, same distance every time. Say each clip once, clearly, with a
smile. LETTER clips are the SOUND ("buh"), not the name ("bee"). Keep each under 2 seconds.
Output: 22.05 kHz mono 16-bit WAV in activities/abc-letters/voice/ (exactly what the app plays).
"""
import argparse, os, shutil, subprocess, sys
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config/includes.chroot/usr/local/lib/kidsos/activities/abc-letters")
sys.path.insert(0, ROOT)
from logic import voice_clips

def path(rel): return os.path.join(ROOT, "voice", rel + ".wav")

def record(dst):
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    p = subprocess.Popen(["arecord", "-q", "-f", "S16_LE", "-r", "22050", "-c", "1", dst])
    input("   ● recording... press Enter to stop ")
    p.terminate(); p.wait()

def clean(f):
    tmp = f + ".tmp.wav"
    trim = "silenceremove=start_periods=1:start_threshold=-45dB:detection=peak"
    af = f"{trim},areverse,{trim},areverse,loudnorm=I=-18:TP=-2"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", f, "-af", af, "-ar", "22050", "-ac", "1",
                    "-sample_fmt", "s16", tmp], check=True)
    os.replace(tmp, f)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--all", action="store_true"); ap.add_argument("--status", action="store_true")
    ap.add_argument("--only", choices=["letters", "words", "prompts"]); ap.add_argument("--clean", action="store_true")
    a = ap.parse_args()
    clips = [c for c in voice_clips() if not a.only or c[0].startswith(a.only + "/")]
    missing = [c for c in clips if not os.path.exists(path(c[0]))]
    if a.status:
        print(f"{len(clips) - len(missing)}/{len(clips)} recorded")
        for rel, text, hint in missing: print("  missing:", rel, "-", text)
        return
    if a.clean:
        if not shutil.which("ffmpeg"): sys.exit("ffmpeg not found")
        for rel, *_ in clips:
            if os.path.exists(path(rel)): clean(path(rel)); print("cleaned", rel)
        return
    for tool in ("arecord", "aplay"):
        if not shutil.which(tool): sys.exit(f"{tool} not found (apt install alsa-utils)")
    todo = clips if a.all else missing
    print(f"{len(todo)} clip(s) to record. Ctrl+C to stop any time; finished clips are kept.\n")
    for n, (rel, text, hint) in enumerate(todo, 1):
        while True:
            print(f"[{n}/{len(todo)}]  SAY: \"{text}\"   ({hint})\n   file: voice/{rel}.wav")
            input("   press Enter to START ")
            record(path(rel))
            subprocess.run(["aplay", "-q", path(rel)])
            ans = input("   Enter = keep, r = redo, s = skip(delete), q = quit: ").strip().lower()
            if ans == "r": continue
            if ans == "s": os.remove(path(rel))
            if ans == "q": return
            break
    print("\nDone. Tip: run  tools/record-voice.py --clean  to trim silence and even out volume.")

if __name__ == "__main__":
    try: main()
    except KeyboardInterrupt: print("\nstopped")
