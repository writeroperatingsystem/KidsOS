#!/bin/bash
# Install the ABC activity on a normal Debian/Ubuntu PC (or a Debian live session) for testing.
#   sudo tools/install-abc.sh              install dependencies + copy files + run the self-check
#   sudo tools/install-abc.sh --no-deps    skip apt (already installed / offline)
#   sudo tools/install-abc.sh --uninstall
# Afterwards:   kidsos-abc --window        (or  kidsos-abc  for full screen)
set -euo pipefail
[ "$(id -u)" -eq 0 ] || exec sudo "$0" "$@"
SRC=$(cd "$(dirname "$0")/.." && pwd)
ACT="$SRC/config/includes.chroot/usr/local/lib/kidsos/activities/abc-letters"
DEST=/usr/local/lib/kidsos/activities/abc-letters
[ -f "$ACT/main.py" ] || { echo "Run this from inside the unpacked kidsos-live folder."; exit 1; }

if [ "${1:-}" = "--uninstall" ]; then rm -rf "$DEST" /usr/local/bin/kidsos-abc; echo "Removed."; exit 0; fi

if [ "${1:-}" != "--no-deps" ]; then
    echo "== Installing dependencies (needs internet) =="
    apt-get update
    apt-get install -y python3 python3-pygame fonts-comic-neue fonts-dejavu-core alsa-utils pciutils
fi

echo "== Copying files =="
rm -rf "$DEST"; mkdir -p "$DEST"; cp -a "$ACT"/. "$DEST"/; find "$DEST" -name __pycache__ -prune -exec rm -rf {} +
install -m 755 "$SRC/config/includes.chroot/usr/local/bin/kidsos-abc" /usr/local/bin/kidsos-abc
chmod -R a+rX "$DEST"; chmod 755 "$DEST/main.py" "$DEST/selfcheck.py"

echo; echo "== Self-check =="
sudo -u "${SUDO_USER:-root}" /usr/local/bin/kidsos-abc --check || true
echo; echo "Installed. Try:  kidsos-abc --window"
