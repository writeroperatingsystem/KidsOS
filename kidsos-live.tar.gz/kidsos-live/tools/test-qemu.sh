#!/bin/bash
# Test with the target minimum: 1 GB RAM. Add -enable-kvm if available.
ISO=${1:-kidsos-0.1-amd64.iso}
exec qemu-system-x86_64 -m 1024 -smp 1 ${KVM:+-enable-kvm} \
  -cdrom "$ISO" -boot d -vga std -audiodev none,id=a -device AC97,audiodev=a
# UEFI test:  add  -bios /usr/share/ovmf/OVMF.fd
