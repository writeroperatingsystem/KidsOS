#!/bin/bash
# Write the ISO to a pendrive and add a "persistence" partition so the child's
# drawings and settings (/home/kid) are saved on the pendrive.
#   sudo tools/make-usb.sh kidsos-0.1-amd64.iso /dev/sdX
set -euo pipefail

ISO=${1:-}; DEV=${2:-}
[ "$(id -u)" -eq 0 ] || { echo "Run as root."; exit 1; }
[ -f "$ISO" ] && [ -b "$DEV" ] || { echo "Usage: $0 image.iso /dev/sdX"; exit 1; }

NAME=$(basename "$DEV")
[ "$(cat /sys/block/$NAME/removable 2>/dev/null || echo 0)" = "1" ] || \
  { echo "$DEV is not flagged removable. Refusing (wrong disk is easy to destroy)."; exit 1; }

if findmnt -rn -S "$DEV" -o TARGET | grep -qx '/'; then echo "That is your system disk."; exit 1; fi

echo "ALL DATA on $DEV will be erased:"; lsblk -o NAME,SIZE,MODEL,TRAN "$DEV"
read -rp "Type the device path again to confirm ($DEV): " CONFIRM
[ "$CONFIRM" = "$DEV" ] || { echo "Aborted."; exit 1; }

umount "$DEV"* 2>/dev/null || true
dd if="$ISO" of="$DEV" bs=4M conv=fsync status=progress
sync

# Persistence partition starts 4 MiB after the end of the ISO image, 1 MiB aligned.
ISO_BYTES=$(stat -c %s "$ISO")
START_MIB=$(( (ISO_BYTES / 1048576) + 5 ))
START_SECTOR=$(( START_MIB * 2048 ))
echo "${START_SECTOR},,83" | sfdisk --append "$DEV"
partprobe "$DEV"; sleep 2

PART=$(lsblk -lnpo NAME "$DEV" | tail -n1)
mkfs.ext4 -F -L persistence -E root_owner=1000:1000 "$PART"

MNT=$(mktemp -d)
mount "$PART" "$MNT"
echo "/home/kid union" > "$MNT/persistence.conf"
umount "$MNT"; rmdir "$MNT"; sync
echo "Done. Boot the pendrive; drawings are saved to the 'persistence' partition."
