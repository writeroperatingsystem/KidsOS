#!/bin/bash
# Update ABC on a KidsOS pendrive WITHOUT rebuilding the ISO, and fetch its logs afterwards.
# Plug the pendrive into your PC, find the mounted partition labelled "persistence", then:
#   tools/push-to-pendrive.sh /media/$USER/persistence            copy the current ABC onto it
#   tools/push-to-pendrive.sh /media/$USER/persistence --logs      copy the logs from it to ./kidsos-logs-<time>
#   tools/push-to-pendrive.sh /media/$USER/persistence --remove    delete the copy (back to the built-in ABC)
# The KidsOS image prefers ~/KidsOS-dev/abc-letters over its built-in ABC when that folder exists.
set -euo pipefail
MNT=${1:?usage: $0 /path/to/persistence-partition [--logs|--remove]}
SRC=$(cd "$(dirname "$0")/.." && pwd)
ACT="$SRC/config/includes.chroot/usr/local/lib/kidsos/activities/abc-letters"
[ -f "$MNT/persistence.conf" ] || { echo "$MNT has no persistence.conf: this is not the KidsOS 'persistence' partition."; exit 1; }
HOME_KID="$MNT/home/kid"

case "${2:-}" in
  --logs)
    [ -d "$HOME_KID/KidsOS-logs" ] || { echo "No logs yet: run KidsOS from this pendrive first."; exit 1; }
    OUT="kidsos-logs-$(date +%Y%m%d-%H%M%S)"; mkdir -p "$OUT"
    sudo cp -a "$HOME_KID/KidsOS-logs/." "$OUT"/; sudo chown -R "$(id -u):$(id -g)" "$OUT"
    echo "Logs copied to ./$OUT :"; ls -1 "$OUT"; exit 0 ;;
  --remove)
    sudo rm -rf "$HOME_KID/KidsOS-dev/abc-letters"; sync; echo "Removed. The pendrive uses the built-in ABC again."; exit 0 ;;
esac

sudo mkdir -p "$HOME_KID/KidsOS-dev"
sudo rm -rf "$HOME_KID/KidsOS-dev/abc-letters"
sudo cp -a "$ACT" "$HOME_KID/KidsOS-dev/abc-letters"; sudo find "$HOME_KID/KidsOS-dev" -name __pycache__ -prune -exec rm -rf {} +
sudo chmod -R a+rX "$HOME_KID/KidsOS-dev"; sudo chmod 755 "$HOME_KID/KidsOS-dev/abc-letters/main.py"
sudo chown -R 1000:1000 "$HOME_KID/KidsOS-dev"
sync
echo "Copied to $HOME_KID/KidsOS-dev/abc-letters"
echo "Now eject the pendrive safely and boot the KidsOS laptop from it."
