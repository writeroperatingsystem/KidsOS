#!/bin/bash
# After a build: list any remaining "Debian" text in the ISO's boot menus.
set -euo pipefail
ISO=${1:?usage: $0 image.iso}
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
if command -v xorriso >/dev/null; then
  xorriso -osirrox on -indev "$ISO" -extract /isolinux "$T/isolinux" -extract /boot/grub "$T/grub" >/dev/null 2>&1 || true
else
  echo "install xorriso (apt install xorriso)"; exit 1
fi
echo "--- 'Debian' occurrences in boot menus (menu text should be clean) ---"
grep -rIn 'Debian' "$T" || echo "none"
echo "--- menu entries ---"
grep -rIhi -E '^\s*(menu (title|label)|menuentry)' "$T" || true
