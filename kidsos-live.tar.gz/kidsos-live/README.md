# KidsOS 0.1 – live-build configuration

Debian 13 (trixie) amd64 hybrid ISO, boots on BIOS and UEFI, runs as a child-only appliance,
and can optionally be installed to the computer's hard drive.

## Principles
- **No accounts, no passwords, no timers, no settings.** There is nothing for anyone to configure.
- Boot straight to the launcher: logo → six big buttons → full-screen activity → back to launcher.
- The child never sees "Debian", a login, a console, a menu, or a boot message.

## What happens at boot
1. **Bootloader:** a blue screen with the KidsOS logo (three blocks and a smile) for 3 seconds. No text.
   *Adult shortcut:* press any key (BIOS) or **Esc** (UEFI) during those 3 seconds to show a menu:
   `KidsOS` · `KidsOS - safe graphics` (for stubborn old GPUs) · `Install KidsOS on this computer (adults)`.
2. **Plymouth splash:** the same logo with three bouncing coloured dots. No boot text.
3. **Launcher:** six large buttons. Closing GCompris/Tux Paint (Esc) returns here.
4. **Power off:** hold the small grey button (bottom-right) for 5 seconds.

## Build (Debian/Ubuntu host, root, internet)
    sudo ./build.sh                       # -> kidsos-0.1-amd64.iso (+ .sha256)
    tools/check-branding.sh kidsos-0.1-amd64.iso   # lists any leftover "Debian" in boot menus

## Test without hardware
    tools/test-qemu.sh kidsos-0.1-amd64.iso        # 1 GB RAM (the minimum spec)
    KVM=1 tools/test-qemu.sh                       # faster if KVM is available

## Pendrive that saves drawings
    sudo tools/make-usb.sh kidsos-0.1-amd64.iso /dev/sdX
Writes the ISO and adds a `persistence` partition (`/home/kid`). A stick written only with `dd`
boots too, but saves nothing.

## Install to the hard drive
1. Boot the pendrive, show the menu (see above), choose **Install KidsOS on this computer (adults)**.
2. Choose the disk. This is the only question: language, clock, network, accounts are preseeded.
   Guided partitioning erases the chosen disk.
3. Reboot without the pendrive. The laptop boots the same appliance. There is no root login
   and no user account with a password on the installed system.

Installed systems are branded too (`/etc/default/grub.d/kidsos.cfg`: hidden GRUB menu, KidsOS name).
The installer's own screens still say Debian: only adults ever see them.

## Servicing a machine
There are no accounts, so servicing = **re-flash the pendrive / re-install**. Drawings live on the
pendrive's `persistence` partition (or `/home/kid` on an installed system).

## Developer debug build (never distribute)
    sudo ./build.sh --debug
Sets root password `root`; reachable only by adding `kidsos.maint` to the kernel line. The normal
build contains no such thing.

## Re-making the artwork
`python3 branding/make-branding.py` regenerates all PNGs (logo, dots, boot splashes) with Pillow.
Preview: `branding/preview-16x9.png`.

## Running a real-hardware test
**Read `FIRST-TEST.md`**: step-by-step (PC check → KidsOS pendrive → collect logs), checklist and troubleshooting.
Tools: `tools/install-abc.sh` (install on a normal PC), `kidsos-abc --check` (self-check), `kidsos-abc --window`,
`tools/push-to-pendrive.sh` (update ABC on the pendrive without rebuilding; `--logs` fetches the logs).

**Logs** (written on the pendrive, folder `~/KidsOS-logs`): `abc.log`, `launcher.log`, `hardware.txt`, `Xorg.0.log`.
Errors never leave the child on a broken screen: a bad frame is logged and skipped; 20 in a row ends ABC and returns to the launcher.
Audio has fallbacks (default driver → ALSA → silent), speakers are un-muted at session start, display falls back to a window.

## ABC activity (letter-to-picture)
`config/includes.chroot/usr/local/lib/kidsos/activities/abc-letters/` · opened by the red **ABC** launcher button.
- **Learn:** a huge "Aa" tile and a huge picture. Tap the letter → its *sound*; tap the picture → its *word*.
  Orange arrows (or the arrow keys) change letter; **typing a letter key jumps to it** (keyboard practice).
  The picture's word is shown small, first letter coloured, as the only reading aid.
- **Match** (green star button): hear a letter sound, tap the picture that starts with it. 8 rounds, three big
  pictures, **no losing**: a wrong tap says what that picture is and "try again"; after two wrong taps the right
  picture blinks. Ends with stars + confetti and three buttons (play again / learn / home).
- 26 original pictures (CC0), soft chime effects, no ads/links/scores. `x` = *box* (the sound is at the END of the word),
  so it appears in Learn but is never used in Match.
- **Real voice is NOT included yet.** Until you record it, ABC plays **placeholder tones** (beeps, not speech) from `voice-placeholder/`;
  real clips in `voice/` automatically win. A clip that exists nowhere is skipped silently (nothing crashes).
      tools/record-voice.py --status         # 56 clips needed
      tools/record-voice.py                  # guided recording: say it, hear it back, keep/redo
      tools/record-voice.py --clean          # trim silence + even out volume (ffmpeg)
  Letter clips are the SOUND ("buh"), not the name ("bee"); the recorder shows the guidance for each.
  *Placeholders:* `tools/make-placeholder-audio.py` (tones) or `--espeak` (robot voice; needs espeak-ng). Never ship them as the final voice.
- Try it on a dev PC (pygame installed): `python3 config/includes.chroot/usr/local/lib/kidsos/activities/abc-letters/main.py --window`
- Tests: `python3 -m unittest discover -s tests` (game rules + a UI smoke test against a pygame stand-in).
- Layout preview: `branding/abc-layout-mockup.png` (mockup, not a screenshot); all pictures: `branding/abc-contact-sheet.png`.
- Regenerate art/sounds: `python3 branding/make-abc-art.py`, `python3 branding/make-abc-sfx.py`.

## Status: UNTESTED SCAFFOLD – verify on first build
1. Package names: `apt-cache search gcompris tuxpaint`. GCompris voices may not exist in Debian.
2. Launcher flags: `gcompris-qt --fullscreen`, `tuxpaint --fullscreen --noprint --savedir=…` (check `--help`).
3. **Bootloader hook** (`0900-…hook.binary`) edits menus by pattern. Unit-tested only against mock files that
   mimic live-build's stock layout; run `tools/check-branding.sh` and fix patterns if "Debian" remains.
4. **Plymouth:** needs the `script` module from the `plymouth` package. Check it renders in QEMU; on some very old
   GPUs it falls back to text/no splash.
5. Installer: confirm it loads `preseed.cfg` and truly asks only for the disk. If it still prompts for
   a user, add `d-i passwd/make-user boolean false` to the installer boot parameters.
6. ABC UI has only run against a pygame *stand-in* (logic + call sequence verified, not real rendering/audio): run it once on a real
   screen with real clips, check the font (Comic Neue's single-storey 'a' is wanted) and touch/mouse feel.
7. Launcher is a placeholder: no icons/voice yet; other five buttons still open GCompris/Tux Paint or nothing (Stories).

## Roadmap
0.1 boots & launches → **0.2 ABC activity (done, needs voice recording)** → 0.3 record voice + test ABC with real children →
0.4 My Pictures gallery + Stories → launcher icons and spoken prompts.
